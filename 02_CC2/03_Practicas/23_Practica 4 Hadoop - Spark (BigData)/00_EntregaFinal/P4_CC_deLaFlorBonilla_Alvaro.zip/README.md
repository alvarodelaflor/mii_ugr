# Cloud Computing - Práctica 4

Antes de nada es importante exportal dos variables de Spark de la siguiente forma:

> export PYSPARK_PYTHON=python3.8

> export PYSPARK_DRIVER_PYTHON=python3.8
