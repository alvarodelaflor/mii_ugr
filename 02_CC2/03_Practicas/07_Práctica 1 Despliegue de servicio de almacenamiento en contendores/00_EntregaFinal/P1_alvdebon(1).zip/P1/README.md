Credenciales en hadoop:

http://hadoop.ugr.es:31010/login?clear=1

User: alvarodelaflor
Pass: password