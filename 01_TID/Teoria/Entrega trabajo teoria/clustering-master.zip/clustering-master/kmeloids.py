from pyclustering.cluster.kmedoids import kmedoids
from pyclustering.utils import timedcall
from sklearn import datasets


def porcentaje(clusters):
    res = []
    i = 0
    total = 0
    for cluster in clusters:
        size = len(cluster)
        total += size
        res.append([i, size])
        i += 1
    for aux in res:
        aux.append(aux[1]*100/total)
    return res

def distancia_media(puntos, meloide, data):
    distancia_media = [0.0, 0.0, 0.0, 0.0]
    for punto in puntos:
        distancia_media[0] += abs(data[meloide][0] - data[punto][0])
        distancia_media[1] += abs(data[meloide][1] - data[punto][1])
        distancia_media[2] += abs(data[meloide][2] - data[punto][2])
        distancia_media[3] += abs(data[meloide][3] - data[punto][3])
    distancia_media[0] = distancia_media[0]/len(puntos)
    distancia_media[1] = distancia_media[1]/len(puntos)
    distancia_media[2] = distancia_media[2]/len(puntos)
    distancia_media[3] = distancia_media[3]/len(puntos)
    return distancia_media


def execute():

    # import iris dataset from sklearn library
    iris = datasets.load_iris()

    # get the iris data. It has 4 features, 3 classes and 150 data points.
    data = iris.data

    """!
    The pyclustering library clarans implementation requires
    list of lists as its input dataset.
    Thus we convert the data from numpy array to list.
    """
    data = data.tolist()

    # get a glimpse of dataset
    print("A peek into the dataset : ", data[:4])

    """!
    @brief Constructor of clustering algorithm CLARANS.
    @details The higher the value of maxneighbor, the closer is CLARANS to K-Medoids, and the longer is each search of a local minima.
    @param[in] data: Input data that is presented as list of points (objects), each point should be represented by list or tuple.
    @param[in] number_clusters: amount of clusters that should be allocated.
    @param[in] numlocal: the number of local minima obtained (amount of iterations for solving the problem).
    @param[in] maxneighbor: the maximum number of neighbors examined.        
    """
    clarans_instance = kmedoids(data, [8, 20, 100])

    # calls the clarans method 'process' to implement the algortihm
    (ticks, result) = timedcall(clarans_instance.process)
    print("K-MELOIDS INICIO")
    print("Execution time : ", ticks, "\n")

    # returns the clusters
    clusters = clarans_instance.get_clusters()

    # returns the mediods
    medoids = clarans_instance.get_medoids()

    print("Index of the points that are in a cluster : ", clusters)
    print("The target class of each datapoint : ", iris.target)
    print("The index of medoids that algorithm found to be best : ", medoids)
    print("Porcentaje: " + str(porcentaje(clusters)))
    for i in range(len(clusters)):
        print("Distancia cluster media" + str(i) + " " + str(distancia_media(clusters[i], medoids[i], data)))
        i += 1
    print("K-MELOIDS FIN")

