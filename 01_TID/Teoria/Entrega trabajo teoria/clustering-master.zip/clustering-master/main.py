import clarans as clarans
import kmeloids as kmeloids

if __name__ == '__main__':
    clarans.execute()
    kmeloids.execute()
