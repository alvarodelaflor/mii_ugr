Godot Grass Shader Tutorial
===========================
This repository contains the example project related to my Godot Grass Shader Tutorial on YouTube.

You can find all my youtube videos related to Godot here:
https://www.youtube.com/channel/UCrbLJYzJjDf2p-vJC011lYw

Also follow me on twitter for regular updates:
https://twitter.com/mux213

LICENSE
-------
The sourcecode found within is licensed under MIT.

Note that images found in the texture folder belong to their respected owners.
See the following sites for more details:
https://textures.com
https://hdrihaven.com
https://opengameart.org/users/yughues
