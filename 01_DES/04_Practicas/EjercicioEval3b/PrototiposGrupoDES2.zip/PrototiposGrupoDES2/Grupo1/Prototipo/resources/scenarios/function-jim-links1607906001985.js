(function(window, undefined) {

  var jimLinks = {
    "7f9941bf-1550-40ec-bd47-5c9a5b382925" : {
      "Button_1" : [
        "64ceef17-3bc9-419a-b976-4f314434498a"
      ],
      "Button_2" : [
        "64ceef17-3bc9-419a-b976-4f314434498a"
      ]
    },
    "8b360097-b1f3-417b-9792-1dff556b253e" : {
      "Button_1" : [
        "64ceef17-3bc9-419a-b976-4f314434498a"
      ],
      "Button_2" : [
        "990f5dbc-0c8b-46cd-a7ce-27aeae4a70ff"
      ]
    },
    "990f5dbc-0c8b-46cd-a7ce-27aeae4a70ff" : {
      "Button_1" : [
        "8b360097-b1f3-417b-9792-1dff556b253e"
      ],
      "Button_2" : [
        "8b360097-b1f3-417b-9792-1dff556b253e"
      ]
    },
    "64ceef17-3bc9-419a-b976-4f314434498a" : {
      "Button_1" : [
        "1477b27a-0968-408f-acfe-78f820e423b0"
      ],
      "Button_2" : [
        "7f9941bf-1550-40ec-bd47-5c9a5b382925"
      ],
      "Button_3" : [
        "8b360097-b1f3-417b-9792-1dff556b253e"
      ],
      "Button_4" : [
        "8b360097-b1f3-417b-9792-1dff556b253e"
      ],
      "Button_5" : [
        "8b360097-b1f3-417b-9792-1dff556b253e"
      ],
      "Button_6" : [
        "8b360097-b1f3-417b-9792-1dff556b253e"
      ]
    },
    "c01fea92-a9f8-431e-a1ff-9c500c25cba9" : {
      "Button_1" : [
        "1477b27a-0968-408f-acfe-78f820e423b0"
      ]
    },
    "1477b27a-0968-408f-acfe-78f820e423b0" : {
      "Button_1" : [
        "64ceef17-3bc9-419a-b976-4f314434498a"
      ],
      "Button_2" : [
        "64ceef17-3bc9-419a-b976-4f314434498a"
      ],
      "Button_3" : [
        "c01fea92-a9f8-431e-a1ff-9c500c25cba9"
      ],
      "Button_4" : [
        "c01fea92-a9f8-431e-a1ff-9c500c25cba9"
      ],
      "Button_6" : [
        "c01fea92-a9f8-431e-a1ff-9c500c25cba9"
      ],
      "Button_5" : [
        "c01fea92-a9f8-431e-a1ff-9c500c25cba9"
      ]
    }    
  }

  window.jimLinks = jimLinks;
})(window);