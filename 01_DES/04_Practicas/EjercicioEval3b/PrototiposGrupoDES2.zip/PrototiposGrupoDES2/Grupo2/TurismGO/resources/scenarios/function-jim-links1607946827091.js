(function(window, undefined) {

  var jimLinks = {
    "40959f6d-ce61-412d-8147-d7974f06962b" : {
      "Hotspot_1" : [
        "619da221-6943-47a2-8d0f-d47b6528de2b"
      ],
      "Hotspot_2" : [
        "56412e41-0cc0-4959-86cb-8aef9fbf97d7"
      ],
      "Hotspot_3" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Hotspot_4" : [
        "40959f6d-ce61-412d-8147-d7974f06962b"
      ],
      "Hotspot_5" : [
        "05375b2d-ee04-4244-b059-6c84b5f24581"
      ],
      "Hotspot_6" : [
        "05375b2d-ee04-4244-b059-6c84b5f24581"
      ],
      "Hotspot_7" : [
        "6975184d-c826-4152-aeef-89829f949a70"
      ]
    },
    "dafe3516-2658-4130-a4d5-cfa0753712b9" : {
      "Hotspot_1" : [
        "56412e41-0cc0-4959-86cb-8aef9fbf97d7"
      ],
      "Hotspot_2" : [
        "dafe3516-2658-4130-a4d5-cfa0753712b9"
      ],
      "Hotspot_3" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Hotspot_4" : [
        "40959f6d-ce61-412d-8147-d7974f06962b"
      ]
    },
    "56412e41-0cc0-4959-86cb-8aef9fbf97d7" : {
      "Hotspot_1" : [
        "619da221-6943-47a2-8d0f-d47b6528de2b"
      ],
      "Hotspot_2" : [
        "619da221-6943-47a2-8d0f-d47b6528de2b"
      ],
      "Hotspot_3" : [
        "56412e41-0cc0-4959-86cb-8aef9fbf97d7"
      ],
      "Hotspot_4" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Hotspot_5" : [
        "40959f6d-ce61-412d-8147-d7974f06962b"
      ],
      "Hotspot_6" : [
        "40959f6d-ce61-412d-8147-d7974f06962b"
      ]
    },
    "619da221-6943-47a2-8d0f-d47b6528de2b" : {
      "Hotspot_1" : [
        "90b6b9e8-3357-42c6-8d30-3e16b0d25098"
      ],
      "Hotspot_2" : [
        "dafe3516-2658-4130-a4d5-cfa0753712b9"
      ],
      "Hotspot_3" : [
        "56412e41-0cc0-4959-86cb-8aef9fbf97d7"
      ],
      "Hotspot_4" : [
        "dafe3516-2658-4130-a4d5-cfa0753712b9"
      ],
      "Hotspot_5" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Hotspot_6" : [
        "40959f6d-ce61-412d-8147-d7974f06962b"
      ]
    },
    "90b6b9e8-3357-42c6-8d30-3e16b0d25098" : {
      "Hotspot_1" : [
        "dafe3516-2658-4130-a4d5-cfa0753712b9"
      ],
      "Hotspot_2" : [
        "619da221-6943-47a2-8d0f-d47b6528de2b"
      ],
      "Hotspot_3" : [
        "56412e41-0cc0-4959-86cb-8aef9fbf97d7"
      ],
      "Hotspot_4" : [
        "dafe3516-2658-4130-a4d5-cfa0753712b9"
      ],
      "Hotspot_5" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Hotspot_6" : [
        "40959f6d-ce61-412d-8147-d7974f06962b"
      ]
    },
    "05375b2d-ee04-4244-b059-6c84b5f24581" : {
      "Hotspot_1" : [
        "619da221-6943-47a2-8d0f-d47b6528de2b"
      ],
      "Hotspot_2" : [
        "56412e41-0cc0-4959-86cb-8aef9fbf97d7"
      ],
      "Hotspot_3" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Hotspot_4" : [
        "40959f6d-ce61-412d-8147-d7974f06962b"
      ],
      "Hotspot_5" : [
        "40959f6d-ce61-412d-8147-d7974f06962b"
      ]
    },
    "6975184d-c826-4152-aeef-89829f949a70" : {
      "Hotspot_1" : [
        "619da221-6943-47a2-8d0f-d47b6528de2b"
      ],
      "Hotspot_2" : [
        "56412e41-0cc0-4959-86cb-8aef9fbf97d7"
      ],
      "Hotspot_3" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Hotspot_4" : [
        "40959f6d-ce61-412d-8147-d7974f06962b"
      ],
      "Hotspot_5" : [
        "05375b2d-ee04-4244-b059-6c84b5f24581"
      ],
      "Hotspot_6" : [
        "05375b2d-ee04-4244-b059-6c84b5f24581"
      ],
      "Hotspot_7" : [
        "05375b2d-ee04-4244-b059-6c84b5f24581"
      ],
      "Hotspot_8" : [
        "40959f6d-ce61-412d-8147-d7974f06962b"
      ]
    },
    "d12245cc-1680-458d-89dd-4f0d7fb22724" : {
      "Hotspot_1" : [
        "56412e41-0cc0-4959-86cb-8aef9fbf97d7"
      ]
    }    
  }

  window.jimLinks = jimLinks;
})(window);