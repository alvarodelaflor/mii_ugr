(function(window, undefined) {
  var dictionary = {
    "40959f6d-ce61-412d-8147-d7974f06962b": "logros_1",
    "dafe3516-2658-4130-a4d5-cfa0753712b9": "TurismGO5",
    "56412e41-0cc0-4959-86cb-8aef9fbf97d7": "TurismGO2",
    "619da221-6943-47a2-8d0f-d47b6528de2b": "TurismGO3",
    "90b6b9e8-3357-42c6-8d30-3e16b0d25098": "TurismGO4",
    "05375b2d-ee04-4244-b059-6c84b5f24581": "logros_3_info",
    "6975184d-c826-4152-aeef-89829f949a70": "logros_2_buscar",
    "d12245cc-1680-458d-89dd-4f0d7fb22724": "TurismGO1",
    "f39803f7-df02-4169-93eb-7547fb8c961a": "Template 1",
    "bb8abf58-f55e-472d-af05-a7d1bb0cc014": "default"
  };

  var uriRE = /^(\/#)?(screens|templates|masters|scenarios)\/(.*)(\.html)?/;
  window.lookUpURL = function(fragment) {
    var matches = uriRE.exec(fragment || "") || [],
        folder = matches[2] || "",
        canvas = matches[3] || "",
        name, url;
    if(dictionary.hasOwnProperty(canvas)) { /* search by name */
      url = folder + "/" + canvas;
    }
    return url;
  };

  window.lookUpName = function(fragment) {
    var matches = uriRE.exec(fragment || "") || [],
        folder = matches[2] || "",
        canvas = matches[3] || "",
        name, canvasName;
    if(dictionary.hasOwnProperty(canvas)) { /* search by name */
      canvasName = dictionary[canvas];
    }
    return canvasName;
  };
})(window);