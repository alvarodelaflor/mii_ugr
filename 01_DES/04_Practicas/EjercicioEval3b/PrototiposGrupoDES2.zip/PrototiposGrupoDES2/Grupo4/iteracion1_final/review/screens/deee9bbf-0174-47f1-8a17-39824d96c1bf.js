var content='<div class="ui-page" deviceName="web" deviceType="desktop" deviceWidth="1280" deviceHeight="800">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devWeb canvas firer commentable non-processed" alignment="left" name="Template 1" width="1280" height="800">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1606909931218.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1606909931218-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><![endif]-->\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
\
    <div id="s-deee9bbf-0174-47f1-8a17-39824d96c1bf" class="screen growth-vertical devWeb canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="RoomHome" width="1280" height="800">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/deee9bbf-0174-47f1-8a17-39824d96c1bf-1606909931218.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/screens/deee9bbf-0174-47f1-8a17-39824d96c1bf-1606909931218-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/screens/deee9bbf-0174-47f1-8a17-39824d96c1bf-1606909931218-ie8.css" /><![endif]-->\
      <div class="freeLayout">\
      <div id="s-Image_1" class="pie image firer ie-background commentable non-processed" customid="Image 1"   datasizewidth="1280.0px" datasizeheight="741.2px" dataX="0.0" dataY="58.8"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/87778c30-2889-4d70-a4bd-ee354e6fe789.png" />\
        	</div>\
        </div>\
      </div>\
\
      <div id="s-Hotspot_1" class="imagemap firer click ie-background commentable non-processed" customid="Hotspot 2"   datasizewidth="170.0px" datasizeheight="61.0px" dataX="662.0" dataY="170.0"  >\
        <div class="clickableSpot"></div>\
      </div>\
      <div id="s-Hotspot_2" class="imagemap firer click ie-background commentable non-processed" customid="Hotspot 3"   datasizewidth="147.0px" datasizeheight="60.0px" dataX="493.0" dataY="170.5"  >\
        <div class="clickableSpot"></div>\
      </div>\
      <div id="s-Hotspot_3" class="imagemap firer click ie-background commentable non-processed" customid="Hotspot 4"   datasizewidth="102.0px" datasizeheight="53.0px" dataX="859.0" dataY="174.0"  >\
        <div class="clickableSpot"></div>\
      </div>\
      <div id="s-Hotspot_4" class="imagemap firer click ie-background commentable non-processed" customid="Hotspot 5"   datasizewidth="117.0px" datasizeheight="53.0px" dataX="335.0" dataY="174.0"  >\
        <div class="clickableSpot"></div>\
      </div>\
      <div id="s-Hotspot_5" class="imagemap firer click ie-background commentable non-processed" customid="Hotspot 5"   datasizewidth="151.0px" datasizeheight="50.0px" dataX="663.0" dataY="82.0"  >\
        <div class="clickableSpot"></div>\
      </div>\
      <div id="s-Hotspot_6" class="imagemap firer click ie-background commentable non-processed" customid="Hotspot 6"   datasizewidth="160.0px" datasizeheight="50.0px" dataX="496.0" dataY="82.0"  >\
        <div class="clickableSpot"></div>\
      </div>\
      <div id="s-Hotspot_7" class="imagemap firer click ie-background commentable non-processed" customid="Hotspot 7"   datasizewidth="154.0px" datasizeheight="50.0px" dataX="335.0" dataY="82.0"  >\
        <div class="clickableSpot"></div>\
      </div>\
      <div id="s-Hotspot_8" class="imagemap firer click ie-background commentable non-processed" customid="Hotspot 8"   datasizewidth="151.0px" datasizeheight="42.0px" dataX="828.0" dataY="86.0"  >\
        <div class="clickableSpot"></div>\
      </div>\
      <div id="s-Hotspot_9" class="imagemap firer click ie-background commentable non-processed" customid="Hotspot 9"   datasizewidth="866.0px" datasizeheight="114.0px" dataX="206.0" dataY="326.0"  >\
        <div class="clickableSpot"></div>\
      </div>\
      <div id="s-Hotspot_10" class="imagemap firer click ie-background commentable non-processed" customid="Hotspot 7"   datasizewidth="252.0px" datasizeheight="50.0px" dataX="1028.0" dataY="82.0"  >\
        <div class="clickableSpot"></div>\
      </div>\
      <div id="s-Button_1" class="pie button multiline manualfit firer ie-background commentable non-processed" customid="Button"   datasizewidth="68.0px" datasizeheight="29.0px" dataX="985.0" dataY="259.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Button_1_0">Crear Sala</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Hotspot_11" class="imagemap firer click ie-background commentable non-processed" customid="Hotspot 11"   datasizewidth="74.0px" datasizeheight="29.0px" dataX="979.0" dataY="259.0"  >\
        <div class="clickableSpot"></div>\
      </div>\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;