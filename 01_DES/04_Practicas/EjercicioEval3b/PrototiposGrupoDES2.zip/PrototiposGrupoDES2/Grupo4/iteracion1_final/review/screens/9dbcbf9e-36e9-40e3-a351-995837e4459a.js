var content='<div class="ui-page" deviceName="web" deviceType="desktop" deviceWidth="1280" deviceHeight="800">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devWeb canvas firer commentable non-processed" alignment="left" name="Template 1" width="1280" height="800">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1606909931218.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1606909931218-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><![endif]-->\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
\
    <div id="s-9dbcbf9e-36e9-40e3-a351-995837e4459a" class="screen growth-vertical devWeb canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="UserPref" width="1280" height="800">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/9dbcbf9e-36e9-40e3-a351-995837e4459a-1606909931218.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/screens/9dbcbf9e-36e9-40e3-a351-995837e4459a-1606909931218-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/screens/9dbcbf9e-36e9-40e3-a351-995837e4459a-1606909931218-ie8.css" /><![endif]-->\
      <div class="freeLayout">\
      <div id="s-Image_1" class="pie image firer ie-background commentable non-processed" customid="Image 1"   datasizewidth="1280.0px" datasizeheight="737.7px" dataX="0.0" dataY="62.3"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/46404c1a-31d4-4402-aa5e-8458925039bc.png" />\
        	</div>\
        </div>\
      </div>\
\
      <div id="s-Hotspot_1" class="imagemap firer click ie-background commentable non-processed" customid="Hotspot 1"   datasizewidth="321.0px" datasizeheight="58.0px" dataX="887.0" dataY="210.0"  >\
        <div class="clickableSpot"></div>\
      </div>\
      <div id="s-Hotspot_2" class="imagemap firer click ie-background commentable non-processed" customid="Hotspot 2"   datasizewidth="298.0px" datasizeheight="48.0px" dataX="887.0" dataY="281.0"  >\
        <div class="clickableSpot"></div>\
      </div>\
      <div id="s-Hotspot_3" class="imagemap firer click ie-background commentable non-processed" customid="Hotspot 3"   datasizewidth="309.0px" datasizeheight="49.0px" dataX="887.0" dataY="339.0"  >\
        <div class="clickableSpot"></div>\
      </div>\
      <div id="s-Hotspot_4" class="imagemap firer click ie-background commentable non-processed" customid="Hotspot 4"   datasizewidth="344.0px" datasizeheight="56.0px" dataX="887.0" dataY="400.0"  >\
        <div class="clickableSpot"></div>\
      </div>\
      <div id="s-Hotspot_5" class="imagemap firer click ie-background commentable non-processed" customid="Hotspot 10"   datasizewidth="151.0px" datasizeheight="50.0px" dataX="610.0" dataY="108.0"  >\
        <div class="clickableSpot"></div>\
      </div>\
      <div id="s-Hotspot_6" class="imagemap firer click ie-background commentable non-processed" customid="Hotspot 11"   datasizewidth="160.0px" datasizeheight="50.0px" dataX="443.0" dataY="108.0"  >\
        <div class="clickableSpot"></div>\
      </div>\
      <div id="s-Hotspot_7" class="imagemap firer click ie-background commentable non-processed" customid="Hotspot 12"   datasizewidth="154.0px" datasizeheight="50.0px" dataX="282.0" dataY="108.0"  >\
        <div class="clickableSpot"></div>\
      </div>\
      <div id="s-Hotspot_8" class="imagemap firer click ie-background commentable non-processed" customid="Hotspot 13"   datasizewidth="151.0px" datasizeheight="42.0px" dataX="775.0" dataY="112.0"  >\
        <div class="clickableSpot"></div>\
      </div>\
      <div id="s-Hotspot_9" class="imagemap firer click ie-background commentable non-processed" customid="Hotspot 7"   datasizewidth="291.0px" datasizeheight="50.0px" dataX="989.0" dataY="104.0"  >\
        <div class="clickableSpot"></div>\
      </div>\
      <div id="s-Hotspot_10" class="imagemap firer click ie-background commentable non-processed" customid="Hotspot 10"   datasizewidth="344.0px" datasizeheight="42.0px" dataX="887.0" dataY="466.0"  >\
        <div class="clickableSpot"></div>\
      </div>\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;