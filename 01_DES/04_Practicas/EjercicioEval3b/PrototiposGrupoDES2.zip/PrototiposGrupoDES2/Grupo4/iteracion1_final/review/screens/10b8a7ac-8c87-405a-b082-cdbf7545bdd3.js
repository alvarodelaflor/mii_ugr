var content='<div class="ui-page" deviceName="web" deviceType="desktop" deviceWidth="1280" deviceHeight="800">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devWeb canvas firer commentable non-processed" alignment="left" name="Template 1" width="1280" height="800">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1606909931218.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1606909931218-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><![endif]-->\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
\
    <div id="s-10b8a7ac-8c87-405a-b082-cdbf7545bdd3" class="screen growth-vertical devWeb canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="UserProfile" width="1280" height="800">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/10b8a7ac-8c87-405a-b082-cdbf7545bdd3-1606909931218.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/screens/10b8a7ac-8c87-405a-b082-cdbf7545bdd3-1606909931218-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/screens/10b8a7ac-8c87-405a-b082-cdbf7545bdd3-1606909931218-ie8.css" /><![endif]-->\
      <div class="freeLayout">\
      <div id="s-Image_1" class="pie image firer ie-background commentable non-processed" customid="Image 1"   datasizewidth="1280.0px" datasizeheight="737.0px" dataX="0.0" dataY="63.0"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/3fddac58-f0f7-4a81-9d1c-c5c6005171ea.png" />\
        	</div>\
        </div>\
      </div>\
\
      <div id="s-Input_1" class="pie text firer commentable non-processed" customid="Input"  datasizewidth="253.0px" datasizeheight="29.0px" dataX="207.0" dataY="325.0" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="Nicki" maxlength="100"  tabindex="-1" placeholder=""/></div></div>  </div></div></div>\
      <div id="s-Input_2" class="pie text firer commentable non-processed" customid="Input"  datasizewidth="453.0px" datasizeheight="29.0px" dataX="574.0" dataY="317.0" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="Minaj" maxlength="100"  tabindex="-1" placeholder=""/></div></div>  </div></div></div>\
      <div id="s-Input_3" class="pie text firer commentable non-processed" customid="Input"  datasizewidth="311.0px" datasizeheight="29.0px" dataX="229.0" dataY="449.0" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder="C/ Daniel Saucedo Aranda s/n"/></div></div>  </div></div></div>\
      <div id="s-Hotspot_1" class="imagemap firer click ie-background commentable non-processed" customid="Hotspot 10"   datasizewidth="151.0px" datasizeheight="50.0px" dataX="653.0" dataY="108.0"  >\
        <div class="clickableSpot"></div>\
      </div>\
      <div id="s-Hotspot_2" class="imagemap firer click ie-background commentable non-processed" customid="Hotspot 11"   datasizewidth="160.0px" datasizeheight="50.0px" dataX="486.0" dataY="108.0"  >\
        <div class="clickableSpot"></div>\
      </div>\
      <div id="s-Hotspot_3" class="imagemap firer click ie-background commentable non-processed" customid="Hotspot 12"   datasizewidth="154.0px" datasizeheight="50.0px" dataX="325.0" dataY="108.0"  >\
        <div class="clickableSpot"></div>\
      </div>\
      <div id="s-Hotspot_4" class="imagemap firer click ie-background commentable non-processed" customid="Hotspot 13"   datasizewidth="151.0px" datasizeheight="42.0px" dataX="818.0" dataY="112.0"  >\
        <div class="clickableSpot"></div>\
      </div>\
      <div id="s-Hotspot_6" class="imagemap firer click ie-background commentable non-processed" customid="Hotspot 7"   datasizewidth="253.0px" datasizeheight="50.0px" dataX="1027.0" dataY="97.0"  >\
        <div class="clickableSpot"></div>\
      </div>\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;