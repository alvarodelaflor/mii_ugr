var content='<div class="ui-page" deviceName="web" deviceType="desktop" deviceWidth="1280" deviceHeight="800">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devWeb canvas firer commentable non-processed" alignment="left" name="Template 1" width="1280" height="800">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1606909931218.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1606909931218-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><![endif]-->\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
\
    <div id="s-dbdcbe95-4fc4-4d9b-bfeb-7fb8afe9b11b" class="screen growth-vertical devWeb canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="SingUp" width="1280" height="800">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/dbdcbe95-4fc4-4d9b-bfeb-7fb8afe9b11b-1606909931218.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/screens/dbdcbe95-4fc4-4d9b-bfeb-7fb8afe9b11b-1606909931218-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/screens/dbdcbe95-4fc4-4d9b-bfeb-7fb8afe9b11b-1606909931218-ie8.css" /><![endif]-->\
      <div class="freeLayout">\
      <div id="s-Image_1" class="pie image firer ie-background commentable non-processed" customid="Image 1"   datasizewidth="1281.9px" datasizeheight="737.0px" dataX="-0.9" dataY="31.5"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/0a64f5ff-0ef9-4ba5-a37c-d24af0acff86.png" />\
        	</div>\
        </div>\
      </div>\
\
      <div id="s-Hotspot_1" class="imagemap firer click ie-background commentable non-processed" customid="Hotspot 1"   datasizewidth="165.0px" datasizeheight="49.0px" dataX="235.0" dataY="554.0"  >\
        <div class="clickableSpot"></div>\
      </div>\
      <div id="s-Input_1" class="pie text firer commentable non-processed" customid="Input"  datasizewidth="311.0px" datasizeheight="29.0px" dataX="144.0" dataY="157.0" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder="Nicki"/></div></div>  </div></div></div>\
      <div id="s-Input_2" class="pie text firer commentable non-processed" customid="Input"  datasizewidth="311.0px" datasizeheight="29.0px" dataX="144.0" dataY="267.0" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder="Minaj"/></div></div>  </div></div></div>\
      <div id="s-Input_3" class="pie text firer commentable non-processed" customid="Input"  datasizewidth="311.0px" datasizeheight="29.0px" dataX="144.0" dataY="371.0" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder="C/ Daniel Saucedo Aranda s/n"/></div></div>  </div></div></div>\
      <div id="s-Category_1" class="pie dropdown firer commentable non-processed" customid="Category"    datasizewidth="143.0px" datasizeheight="29.0px" dataX="144.0" dataY="467.0"  tabindex="-1"><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content icon"><div class="valign"><div class="value">Granada</div></div></div></div></div><select id="s-Category_1-options" class="s-dbdcbe95-4fc4-4d9b-bfeb-7fb8afe9b11b dropdown-options" ><option selected="selected" class="option">Granada</option>\
      <option  class="option">C&aacute;diz</option>\
      <option  class="option">Madrid</option></select></div>\
      <div id="s-Category_2" class="pie dropdown firer commentable non-processed" customid="Category"    datasizewidth="129.0px" datasizeheight="29.0px" dataX="336.0" dataY="467.0"  tabindex="-1"><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content icon"><div class="valign"><div class="value">Spain</div></div></div></div></div><select id="s-Category_2-options" class="s-dbdcbe95-4fc4-4d9b-bfeb-7fb8afe9b11b dropdown-options" ><option selected="selected" class="option">Spain</option>\
      <option  class="option">US</option>\
      <option  class="option">Germany</option></select></div>\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;