var content='<div class="ui-page" deviceName="web" deviceType="desktop" deviceWidth="1280" deviceHeight="800">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devWeb canvas firer commentable non-processed" alignment="left" name="Template 1" width="1280" height="800">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1606909931218.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1606909931218-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1606909931218-ie8.css" /><![endif]-->\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
\
    <div id="s-f96edb89-8c78-4f77-8e8d-7fc8b8fd28e6" class="screen growth-vertical devWeb canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="Categories" width="1280" height="800">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/f96edb89-8c78-4f77-8e8d-7fc8b8fd28e6-1606909931218.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/screens/f96edb89-8c78-4f77-8e8d-7fc8b8fd28e6-1606909931218-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/screens/f96edb89-8c78-4f77-8e8d-7fc8b8fd28e6-1606909931218-ie8.css" /><![endif]-->\
      <div class="freeLayout">\
      <div id="s-Image_1" class="pie image firer ie-background commentable non-processed" customid="Image 1"   datasizewidth="1280.9px" datasizeheight="733.8px" dataX="-0.5" dataY="66.2"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/2108fd6b-ba02-41b0-aac0-4ace7f04d8f6.png" />\
        	</div>\
        </div>\
      </div>\
\
      <div id="s-Hotspot_1" class="imagemap firer click ie-background commentable non-processed" customid="Hotspot 3"   datasizewidth="154.0px" datasizeheight="50.0px" dataX="319.0" dataY="118.0"  >\
        <div class="clickableSpot"></div>\
      </div>\
      <div id="s-Hotspot_2" class="imagemap firer click ie-background commentable non-processed" customid="Hotspot 3"   datasizewidth="160.0px" datasizeheight="50.0px" dataX="480.0" dataY="118.0"  >\
        <div class="clickableSpot"></div>\
      </div>\
      <div id="s-Hotspot_3" class="imagemap firer click ie-background commentable non-processed" customid="Hotspot 4"   datasizewidth="151.0px" datasizeheight="50.0px" dataX="646.0" dataY="118.0"  >\
        <div class="clickableSpot"></div>\
      </div>\
      <div id="s-Hotspot_4" class="imagemap firer click ie-background commentable non-processed" customid="Hotspot 5"   datasizewidth="151.0px" datasizeheight="42.0px" dataX="807.0" dataY="118.0"  >\
        <div class="clickableSpot"></div>\
      </div>\
      <div id="s-Hotspot_5" class="imagemap firer click ie-background commentable non-processed" customid="Hotspot 5"   datasizewidth="192.0px" datasizeheight="104.0px" dataX="235.0" dataY="252.0"  >\
        <div class="clickableSpot"></div>\
      </div>\
      <div id="s-Hotspot_6" class="imagemap firer click ie-background commentable non-processed" customid="Hotspot 7"   datasizewidth="291.0px" datasizeheight="50.0px" dataX="982.0" dataY="118.0"  >\
        <div class="clickableSpot"></div>\
      </div>\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;