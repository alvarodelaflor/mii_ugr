var content='<div class="ui-page" deviceName="web" deviceType="desktop" deviceWidth="1280" deviceHeight="800">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devWeb canvas firer commentable non-processed" alignment="left" name="Template 1" width="1280" height="800">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1606909931218.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1606909931218-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><![endif]-->\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
\
    <div id="s-fef566e6-833c-48b3-b156-98fc5185581e" class="screen growth-vertical devWeb canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="Game" width="1280" height="800">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/fef566e6-833c-48b3-b156-98fc5185581e-1606909931218.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/screens/fef566e6-833c-48b3-b156-98fc5185581e-1606909931218-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/screens/fef566e6-833c-48b3-b156-98fc5185581e-1606909931218-ie8.css" /><![endif]-->\
      <div class="freeLayout">\
      <div id="s-Image_1" class="pie image firer ie-background commentable non-processed" customid="Image 1"   datasizewidth="1280.0px" datasizeheight="730.8px" dataX="0.0" dataY="69.2"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/89dac3c7-b3d9-49de-845e-bb08b96a1520.png" />\
        	</div>\
        </div>\
      </div>\
\
      <div id="s-Hotspot_1" class="imagemap firer click ie-background commentable non-processed" customid="Hotspot 1"   datasizewidth="123.0px" datasizeheight="60.0px" dataX="502.0" dataY="221.0"  >\
        <div class="clickableSpot"></div>\
      </div>\
      <div id="s-Hotspot_2" class="imagemap firer click ie-background commentable non-processed" customid="Hotspot 2"   datasizewidth="170.0px" datasizeheight="61.0px" dataX="640.0" dataY="227.0"  >\
        <div class="clickableSpot"></div>\
      </div>\
      <div id="s-Hotspot_3" class="imagemap firer click ie-background commentable non-processed" customid="Hotspot 3"   datasizewidth="102.0px" datasizeheight="53.0px" dataX="844.0" dataY="221.0"  >\
        <div class="clickableSpot"></div>\
      </div>\
      <div id="s-Hotspot_4" class="imagemap firer click ie-background commentable non-processed" customid="Hotspot 4"   datasizewidth="117.0px" datasizeheight="53.0px" dataX="326.0" dataY="238.0"  >\
        <div class="clickableSpot"></div>\
      </div>\
      <div id="s-Hotspot_5" class="imagemap firer click ie-background commentable non-processed" customid="Hotspot 5"   datasizewidth="151.0px" datasizeheight="50.0px" dataX="640.0" dataY="100.0"  >\
        <div class="clickableSpot"></div>\
      </div>\
      <div id="s-Hotspot_6" class="imagemap firer click ie-background commentable non-processed" customid="Hotspot 6"   datasizewidth="160.0px" datasizeheight="50.0px" dataX="473.0" dataY="100.0"  >\
        <div class="clickableSpot"></div>\
      </div>\
      <div id="s-Hotspot_7" class="imagemap firer click ie-background commentable non-processed" customid="Hotspot 7"   datasizewidth="154.0px" datasizeheight="50.0px" dataX="312.0" dataY="100.0"  >\
        <div class="clickableSpot"></div>\
      </div>\
      <div id="s-Hotspot_8" class="imagemap firer click ie-background commentable non-processed" customid="Hotspot 8"   datasizewidth="151.0px" datasizeheight="42.0px" dataX="805.0" dataY="104.0"  >\
        <div class="clickableSpot"></div>\
      </div>\
      <div id="s-Hotspot_9" class="imagemap firer click ie-background commentable non-processed" customid="Hotspot 7"   datasizewidth="291.0px" datasizeheight="50.0px" dataX="997.0" dataY="100.0"  >\
        <div class="clickableSpot"></div>\
      </div>\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;