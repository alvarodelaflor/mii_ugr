(function(window, undefined) {

  var jimLinks = {
    "f69f613b-7b18-4a55-84fb-39befdd2b2a9" : {
      "Paragraph_6" : [
        "99f7eb99-a46f-4906-a212-003e0974edb5"
      ],
      "Rectangle_3" : [
        "6da2ddce-792b-4cc6-8641-f26f033259ca"
      ]
    },
    "99f7eb99-a46f-4906-a212-003e0974edb5" : {
      "Paragraph_4" : [
        "75a48058-c3b6-49b0-acd3-b859bfd7f666"
      ]
    },
    "6da2ddce-792b-4cc6-8641-f26f033259ca" : {
      "Rectangle_5" : [
        "f69f613b-7b18-4a55-84fb-39befdd2b2a9"
      ]
    },
    "75a48058-c3b6-49b0-acd3-b859bfd7f666" : {
    },
    "50d86665-1fec-447c-bff0-2943e539154c" : {
      "Paragraph_4" : [
        "75a48058-c3b6-49b0-acd3-b859bfd7f666"
      ],
      "Paragraph_5" : [
        "f69f613b-7b18-4a55-84fb-39befdd2b2a9"
      ],
      "Paragraph_6" : [
        "99f7eb99-a46f-4906-a212-003e0974edb5"
      ]
    },
    "96789c27-aabb-4f0e-8a60-99f02883e29b" : {
      "Rectangle_2" : [
        "50d86665-1fec-447c-bff0-2943e539154c"
      ]
    },
    "d12245cc-1680-458d-89dd-4f0d7fb22724" : {
      "Rectangle_3" : [
        "96789c27-aabb-4f0e-8a60-99f02883e29b"
      ]
    }    
  }

  window.jimLinks = jimLinks;
})(window);