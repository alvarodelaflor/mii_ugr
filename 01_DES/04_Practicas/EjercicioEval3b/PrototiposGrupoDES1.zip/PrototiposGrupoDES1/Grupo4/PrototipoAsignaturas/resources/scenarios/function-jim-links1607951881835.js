(function(window, undefined) {

  var jimLinks = {
    "cc9f39d6-326b-4f7f-8abd-67c5ac52dc6d" : {
    },
    "a57d8f41-fea9-47cb-b35b-41f2be0f2a4c" : {
      "Image_9" : [
        "d54f8a0c-ff77-4048-b41d-4c3127fd48f3"
      ]
    },
    "bac3b510-67c6-4497-ae9a-197a98577a18" : {
      "Image_10" : [
        "a57d8f41-fea9-47cb-b35b-41f2be0f2a4c"
      ]
    },
    "d54f8a0c-ff77-4048-b41d-4c3127fd48f3" : {
      "Image_9" : [
        "cc9f39d6-326b-4f7f-8abd-67c5ac52dc6d"
      ]
    },
    "d12245cc-1680-458d-89dd-4f0d7fb22724" : {
      "Paragraph_6" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Image_9" : [
        "bac3b510-67c6-4497-ae9a-197a98577a18"
      ]
    }    
  }

  window.jimLinks = jimLinks;
})(window);