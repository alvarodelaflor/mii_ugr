var content='<div class="ui-page" deviceName="web" deviceType="desktop" deviceWidth="1280" deviceHeight="800">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devWeb canvas firer commentable non-processed" alignment="left" name="Template 1" width="1280" height="800">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1607951997288.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1607951997288-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><![endif]-->\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
\
    <div id="s-d12245cc-1680-458d-89dd-4f0d7fb22724" class="screen growth-vertical devWeb canvas PORTRAIT firer commentable non-processed" alignment="left" name="Registrarse" width="1280" height="800">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/d12245cc-1680-458d-89dd-4f0d7fb22724-1607951997288.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/screens/d12245cc-1680-458d-89dd-4f0d7fb22724-1607951997288-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/screens/d12245cc-1680-458d-89dd-4f0d7fb22724-1607951997288-ie8.css" /><![endif]-->\
      <div class="freeLayout">\
      <div id="s-Paragraph_1" class="pie richtext autofit firer ie-background commentable non-processed" customid="Paragraph"   datasizewidth="245.4px" datasizeheight="55.0px" dataX="515.0" dataY="106.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_1_0">UNITOOLS</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Rectangle_1" class="pie rectangle manualfit firer commentable non-processed" customid="Rectangle_6"   datasizewidth="590.0px" datasizeheight="447.0px" datasizewidthpx="590.0" datasizeheightpx="447.00000000000006" dataX="343.0" dataY="216.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_1_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Input_1" class="pie text firer commentable non-processed" customid="Input_4"  datasizewidth="345.0px" datasizeheight="46.0px" dataX="385.0" dataY="248.0" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder="Nombre"/></div></div>  </div></div></div>\
      <div id="s-Input_2" class="pie text firer commentable non-processed" customid="Input_4"  datasizewidth="345.0px" datasizeheight="46.0px" dataX="385.0" dataY="308.0" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder="Usuario"/></div></div>  </div></div></div>\
\
      <div id="s-Group_1" class="group firer ie-background commentable non-processed" customid="Group_1" datasizewidth="150.0px" datasizeheight="45.0px" >\
        <div id="s-Rectangle_2" class="pie rectangle manualfit firer click commentable non-processed" customid="Rectangle_1"   datasizewidth="181.0px" datasizeheight="62.0px" datasizewidthpx="180.9999999999999" datasizeheightpx="62.00000000000023" dataX="715.0" dataY="571.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Rectangle_2_0">Registrarse</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
\
        <div id="s-Image_1" class="pie image firer ie-background commentable non-processed" customid="Image_1"   datasizewidth="16.0px" datasizeheight="18.0px" dataX="745.0" dataY="589.0"   alt="image" systemName="./images/8e3fb510-f732-48a2-b1af-c8da21b87d96.svg" overlay="#FFFFFF">\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" height="20px" version="1.1" viewBox="0 0 17 20" width="17px">\
            	    <!-- Generator: Sketch 49.3 (51167) - http://www.bohemiancoding.com/sketch -->\
            	    <title>Page 1</title>\
            	    <desc>Created with Sketch.</desc>\
            	    <defs>\
            	        <polygon id="s-Image_1-path-1" points="0 1.12646002e-05 16.9999924 1.12646002e-05 16.9999924 7.96031746 0 7.96031746" fill="#FFFFFF" jimofill=" " />\
            	    </defs>\
            	    <g fill="none" fill-rule="evenodd" id="s-Image_1-Page-1" stroke="none" stroke-width="1">\
            	        <g id="Header-#4" transform="translate(-1082.000000, -25.000000)">\
            	            <g id="s-Image_1-Page-1" transform="translate(1082.000000, 25.000000)">\
            	                <path d="M8.63492063,0 C5.80790159,0 3.50793651,2.29996508 3.50793651,5.12698413 C3.50793651,7.95400317 5.80790159,10.2539683 8.63492063,10.2539683 C11.4619397,10.2539683 13.7619048,7.95400317 13.7619048,5.12698413 C13.7619048,2.29996508 11.4619397,0 8.63492063,0" fill="#666666" id="s-Image_1-Fill-1" style="fill:#FFFFFF !important;" />\
            	                <g id="s-Image_1-Group-5" transform="translate(0.000000, 11.468254)">\
            	                    <mask fill="white" id="s-Image_1-mask-2">\
            	                        <use xlink:href="#s-Image_1-path-1" style="fill:#FFFFFF !important;" />\
            	                    </mask>\
            	                    <g id="s-Image_1-Clip-4" />\
            	                    <path d="M9.63332578,1.12646002e-05 L7.36665911,1.12646002e-05 C5.40191244,1.12646002e-05 3.55087689,0.776029571 2.15461022,2.18515596 C0.765181333,3.58737339 -7.55555556e-06,5.43829739 -7.55555556e-06,7.39709872 C-7.55555556e-06,7.70815188 0.253708,7.96032872 0.566659111,7.96032872 L16.4333258,7.96032872 C16.7462769,7.96032872 16.9999924,7.70815188 16.9999924,7.39709872 C16.9999924,5.43829739 16.2348036,3.58737339 14.8453747,2.18515596 C13.449108,0.776029571 11.5981102,1.12646002e-05 9.63332578,1.12646002e-05 Z" fill="#666666" id="s-Image_1-Fill-3" mask="url(#s-Image_1-mask-2)" style="fill:#FFFFFF !important;" />\
            	                </g>\
            	            </g>\
            	        </g>\
            	    </g>\
            	</svg>\
\
            </div>\
          </div>\
        </div>\
\
      </div>\
\
      <div id="s-Input_3" class="pie text firer commentable non-processed" customid="Input_4"  datasizewidth="345.0px" datasizeheight="46.0px" dataX="385.0" dataY="367.0" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder="Correo"/></div></div>  </div></div></div>\
      <div id="s-Input_4" class="pie text firer commentable non-processed" customid="Input_4"  datasizewidth="345.0px" datasizeheight="46.0px" dataX="385.0" dataY="426.0" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder="Contraseña"/></div></div>  </div></div></div>\
      <div id="s-Input_5" class="pie text firer commentable non-processed" customid="Input_4"  datasizewidth="345.0px" datasizeheight="46.0px" dataX="385.0" dataY="483.0" ><div class="backgroundLayer">\
        <div class="colorLayer"></div>\
        <div class="imageLayer"></div>\
      </div><div class="borderLayer"><div class="paddingLayer"><div class="content"><div class="valign"><input type="text"  value="" maxlength="100"  tabindex="-1" placeholder="Repetir contraseña"/></div></div>  </div></div></div>\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;