var content='<div class="ui-page" deviceName="web" deviceType="desktop" deviceWidth="1280" deviceHeight="800">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devWeb canvas firer commentable non-processed" alignment="left" name="Template 1" width="1280" height="800">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1607951997288.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1607951997288-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><![endif]-->\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
\
    <div id="s-75e1b7fb-c27f-4b2e-8283-0894efb179f1" class="screen growth-vertical devWeb canvas PORTRAIT firer commentable non-processed" alignment="left" name="Piso" width="1280" height="800">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/75e1b7fb-c27f-4b2e-8283-0894efb179f1-1607951997288.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/screens/75e1b7fb-c27f-4b2e-8283-0894efb179f1-1607951997288-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/screens/75e1b7fb-c27f-4b2e-8283-0894efb179f1-1607951997288-ie8.css" /><![endif]-->\
      <div class="freeLayout">\
      <div id="s-Paragraph_1" class="pie richtext manualfit firer mouseenter mouseleave ie-background commentable non-processed" customid="Paragraph_8"   datasizewidth="290.0px" datasizeheight="32.0px" dataX="-0.0" dataY="727.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_1_0">LEY DE PROTECCI&Oacute;N DE DATOS</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_2" class="pie richtext manualfit firer mouseenter mouseleave ie-background commentable non-processed" customid="Paragraph_8"   datasizewidth="290.0px" datasizeheight="32.0px" dataX="303.0" dataY="727.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_2_0">LEY DE USO DE COOKIES</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Image_1" class="pie image firer ie-background commentable non-processed" customid="Image_32"   datasizewidth="49.0px" datasizeheight="41.5px" dataX="1095.8" dataY="706.3"   alt="image" systemName="./images/eae1ba15-2b86-460b-ac3f-43d09d8e3f8c.svg" overlay="#000000">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" height="14px" version="1.1" viewBox="0 0 16 14" width="16px">\
          	    <!-- Generator: Sketch 49.3 (51167) - http://www.bohemiancoding.com/sketch -->\
          	    <title>Twitter Icon</title>\
          	    <desc>Created with Sketch.</desc>\
          	    <defs />\
          	    <g fill="none" fill-rule="evenodd" id="s-Image_1-Page-1" stroke="none" stroke-width="1">\
          	        <g fill="#B2B2B2" id="s-Image_1-Components" transform="translate(-385.000000, -929.000000)">\
          	            <g id="s-Image_1-Social" transform="translate(100.000000, 849.000000)">\
          	                <g id="s-Image_1-Social-Stroked" transform="translate(255.000000, 2.000000)">\
          	                    <g id="s-Image_1-Twitter" transform="translate(0.000000, 64.380952)">\
          	                        <path d="M40.5826772,15.0284341 C41.3385827,14.8743697 41.7165354,14.5662407 41.8425197,14.4121762 C41.8425197,14.2581118 41.8425197,14.1040473 41.7165354,14.1040473 C41.3385827,14.1040473 40.9606299,14.2581118 40.7086614,14.4121762 C41.0866142,14.1040473 41.2125984,13.9499828 41.2125984,13.7959184 C40.8346457,13.7959184 40.4566929,14.1040473 39.9527559,14.5662407 C40.0787402,14.2581118 40.2047244,14.1040473 40.0787402,13.9499828 C39.8267717,14.1040473 39.7007874,14.2581118 39.5748031,14.5662407 C39.1968504,15.0284341 38.9448819,15.3365631 38.8188976,15.7987565 C38.3149606,16.8772078 37.9370079,17.8015946 37.6850394,18.8800459 L37.5590551,18.8800459 C37.3070866,18.4178525 36.9291339,17.9556591 36.4251969,17.6475301 C35.9212598,17.1853367 35.2913386,16.8772078 34.5354331,16.4150144 C33.7795276,15.952821 33.023622,15.4906275 32.1417323,15.1824986 C32.1417323,16.2609499 32.519685,17.1853367 33.4015748,17.8015946 C33.1496063,17.8015946 32.7716535,17.8015946 32.519685,17.9556591 C32.519685,18.8800459 33.1496063,19.6503682 34.2834646,19.9584972 C33.9055118,19.9584972 33.5275591,20.1125617 33.1496063,20.4206906 C33.5275591,21.3450774 34.1574803,21.6532064 35.1653543,21.6532064 C35.0393701,21.8072708 34.7874016,21.9613353 34.7874016,21.9613353 C34.6614173,22.1153998 34.5354331,22.4235287 34.6614173,22.7316577 C34.9133858,23.1938511 35.1653543,23.3479155 35.7952756,23.3479155 C34.9133858,24.4263668 33.7795276,25.0426247 32.519685,24.8885602 C31.7637795,24.8885602 30.8818898,24.4263668 30,23.50198 C30.8818898,25.0426247 32.1417323,26.2751405 33.6535433,27.0454628 C35.4173228,27.6617207 37.1811024,27.8157852 38.8188976,27.1995273 C40.4566929,26.5832694 41.9685039,25.3507537 43.1023622,23.6560445 C43.6062992,22.7316577 43.984252,21.8072708 44.1102362,20.882884 C44.992126,20.882884 45.6220472,20.5747551 46,19.9584972 C45.7480315,20.1125617 45.1181102,20.1125617 44.2362205,19.8044327 C45.1181102,19.6503682 45.7480315,19.3422393 45.8740157,18.7259814 C45.2440945,19.0341104 44.6141732,19.0341104 43.984252,18.7259814 C43.8582677,17.6475301 43.480315,16.7231433 42.7244094,15.952821 C42.0944882,15.1824986 41.3385827,14.8743697 40.5826772,15.0284341 Z" id="s-Image_1-Twitter-Icon" style="fill:#000000 !important;" />\
          	                    </g>\
          	                </g>\
          	            </g>\
          	        </g>\
          	    </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
\
\
      <div id="s-Image_2" class="pie image firer ie-background commentable non-processed" customid="Image_20"   datasizewidth="45.0px" datasizeheight="39.5px" dataX="1153.0" dataY="707.3"   alt="image" systemName="./images/0d42d05b-3417-4aad-bb62-36c0da512583.svg" overlay="#000000">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" height="15px" version="1.1" viewBox="0 0 20 15" width="20px">\
          	    <!-- Generator: Sketch 49.3 (51167) - http://www.bohemiancoding.com/sketch -->\
          	    <title>Mail Icon</title>\
          	    <desc>Created with Sketch.</desc>\
          	    <defs />\
          	    <g fill="none" fill-rule="evenodd" id="s-Image_2-Page-1" stroke="none" stroke-width="1">\
          	        <g fill="#DDDDDD" id="s-Image_2-Components" transform="translate(-820.000000, -936.000000)">\
          	            <g id="s-Image_2-Social" transform="translate(100.000000, 849.000000)">\
          	                <g id="s-Image_2-Contacts" transform="translate(720.000000, 87.000000)">\
          	                    <g id="s-Image_2-Mail-Icon">\
          	                        <path d="M20,13.625 C20,14.375 19.4002307,15 18.7312572,15 L1.26874279,15 C0.599769319,15 0,14.375 0,13.625 L0,1.425 C0,0.7 0.553633218,0.1 1.22260669,0.075 L1.24567474,0 L18.7081892,0 L18.7312572,0.075 L19.0311419,0.075 L18.7312572,0.075 C19.4232987,0.075 20,0.675 20,1.425 L20,13.625 Z M18.4544406,11.675 L18.4544406,3.325 L13.4025375,7.5 L18.4544406,11.675 Z M18.4544406,1.675 L1.5455594,1.675 C4.35986159,3.975 7.17416378,6.275 9.98846597,8.6 C12.8027682,6.275 15.6170704,3.975 18.4544406,1.675 L18.4544406,1.675 Z M18.4544406,13.325 L12.3644752,8.35 L10.7497116,9.7 L9.20415225,9.7 L7.61245675,8.375 L1.5455594,13.325 L18.4544406,13.325 Z M6.57439446,7.5 L1.5455594,3.325 L1.5455594,11.675 L6.57439446,7.5 Z" style="fill:#000000 !important;" />\
          	                    </g>\
          	                </g>\
          	            </g>\
          	        </g>\
          	    </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
\
\
      <div id="s-Image_3" class="pie image firer ie-background commentable non-processed" customid="Image_11"   datasizewidth="28.0px" datasizeheight="41.5px" dataX="1051.0" dataY="706.3"   alt="image" systemName="./images/9e09f077-47ce-49a5-8d21-2c1d4b293400.svg" overlay="#000000">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
          	<?xml version="1.0" encoding="UTF-8"?>\
          	<svg preserveAspectRatio=\'none\' xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" height="19px" version="1.1" viewBox="0 0 8 19" width="8px">\
          	    <!-- Generator: Sketch 49.3 (51167) - http://www.bohemiancoding.com/sketch -->\
          	    <title>Facebook Icon</title>\
          	    <desc>Created with Sketch.</desc>\
          	    <defs />\
          	    <g fill="none" fill-rule="evenodd" id="s-Image_3-Page-1" stroke="none" stroke-width="1">\
          	        <g fill="#B2B2B2" id="s-Image_3-Components" transform="translate(-389.000000, -863.000000)">\
          	            <g id="s-Image_3-Social" transform="translate(100.000000, 849.000000)">\
          	                <g id="s-Image_3-Social-Stroked" transform="translate(255.000000, 2.000000)">\
          	                    <g id="s-Image_3-Facebook">\
          	                        <path d="M41.5628415,15.4028982 C41.1256831,15.2561332 40.6229508,15.1582898 40.1639344,15.1582898 C39.5956284,15.1582898 38.3715847,15.5741242 38.3715847,16.3813322 L38.3715847,18.3137392 L41.2786885,18.3137392 L41.2786885,21.567032 L38.3715847,21.567032 L38.3715847,30.5441633 L35.442623,30.5441633 L35.442623,21.567032 L34,21.567032 L34,18.3137392 L35.442623,18.3137392 L35.442623,16.6748624 C35.442623,14.2043167 36.4480874,12.1496054 38.8743169,12.1496054 C39.704918,12.1496054 41.1912568,12.1985271 42,12.5165182 L41.5628415,15.4028982 Z" id="s-Image_3-Facebook-Icon" style="fill:#000000 !important;" />\
          	                    </g>\
          	                </g>\
          	            </g>\
          	        </g>\
          	    </g>\
          	</svg>\
\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Paragraph_3" class="pie richtext autofit firer ie-background commentable non-processed" customid="Paragraph"   datasizewidth="1.0px" datasizeheight="1.0px" dataX="233.0" dataY="450.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_3_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Group_1" class="group firer ie-background commentable non-processed" customid="Group_1" datasizewidth="1024.0px" datasizeheight="70.0px" >\
        <div id="s-Rectangle_1" class="pie rectangle manualfit firer commentable non-processed" customid="Rectangle_1"   datasizewidth="1280.0px" datasizeheight="70.0px" datasizewidthpx="1280.0000000000005" datasizeheightpx="70.0" dataX="0.0" dataY="1.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Rectangle_1_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Paragraph_4" class="pie richtext manualfit firer mousedown mouseup ie-background commentable non-processed" customid="Text_1"   datasizewidth="125.0px" datasizeheight="70.0px" dataX="474.0" dataY="1.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Paragraph_4_0">INICIO</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Paragraph_5" class="pie richtext manualfit firer mousedown mouseup ie-background commentable non-processed" customid="Text_2"   datasizewidth="149.0px" datasizeheight="70.0px" dataX="599.0" dataY="1.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Paragraph_5_0">PISOS/RESIDENCIAS</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Paragraph_6" class="pie richtext manualfit firer mousedown mouseup ie-background commentable non-processed" customid="Text_3"   datasizewidth="125.0px" datasizeheight="70.0px" dataX="764.0" dataY="1.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Paragraph_6_0">ASIGNATURAS</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Paragraph_7" class="pie richtext autofit firer ie-background commentable non-processed" customid="Paragraph"   datasizewidth="122.7px" datasizeheight="27.0px" dataX="25.0" dataY="22.5" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_7_0">UNITOOLS</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Group_2" class="group firer ie-background commentable non-processed" customid="Promo_4" datasizewidth="1024.0px" datasizeheight="450.0px" >\
        <div id="s-Rectangle_2" class="pie rectangle manualfit firer commentable non-processed" customid="Bg"   datasizewidth="1024.0px" datasizeheight="450.0px" datasizewidthpx="1024.0" datasizeheightpx="450.0" dataX="129.0" dataY="176.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Rectangle_2_0"></span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Paragraph_8" class="pie richtext manualfit firer ie-background commentable non-processed" customid="Title"   datasizewidth="481.0px" datasizeheight="112.0px" dataX="154.0" dataY="192.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Paragraph_8_0">Calle Guti&eacute;rrez 12, 2&ordm;B - 250&euro;/mes</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
        <div id="s-Paragraph_9" class="pie richtext manualfit firer ie-background commentable non-processed" customid="Paragraph"   datasizewidth="400.0px" datasizeheight="81.0px" dataX="154.0" dataY="295.0" >\
          <div class="backgroundLayer">\
            <div class="colorLayer"></div>\
            <div class="imageLayer"></div>\
          </div>\
          <div class="borderLayer">\
            <div class="paddingLayer">\
              <div class="content">\
                <div class="valign">\
                  <span id="rtr-s-Paragraph_9_0">Hola somos dos estudiantes que buscamos compa&ntilde;ero para el curso 2020-2021</span>\
                </div>\
              </div>\
            </div>\
          </div>\
        </div>\
\
        <div id="s-Image_4" class="pie image lockV firer ie-background commentable non-processed" customid="Arrow_left"   datasizewidth="42.0px" datasizeheight="42.0px" dataX="879.0" dataY="567.0" aspectRatio="1.0"   alt="image" systemName="./images/de68f8c1-1717-473e-ad0c-aa1eedcf0dd0.svg" overlay="">\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg preserveAspectRatio=\'none\' width="68px" height="68px" viewBox="0 0 68 68" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">\
            	    <!-- Generator: Sketch 49.3 (51167) - http://www.bohemiancoding.com/sketch -->\
            	    <title>Stroked Arrow Left</title>\
            	    <desc>Created with Sketch.</desc>\
            	    <defs></defs>\
            	    <g id="s-Image_4-Page-1" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">\
            	        <g id="Slider-#9" transform="translate(-98.000000, -243.000000)">\
            	            <g id="s-Image_4-Stroked-Arrow-Left" transform="translate(99.000000, 244.000000)">\
            	                <circle id="s-Image_4-Stroke" stroke="#CBCBCB" cx="33" cy="33" r="33"></circle>\
            	                <g id="s-Image_4-Arrow-Left" transform="translate(23.000000, 19.000000)" fill="#CBCBCB">\
            	                    <polyline transform="translate(8.000000, 14.000000) scale(-1, 1) translate(-8.000000, -14.000000) " points="1.157 0 0 1.144 12.325 13.62 0 25.691 1.325 27 15 13.691 1.157 0"></polyline>\
            	                </g>\
            	            </g>\
            	        </g>\
            	    </g>\
            	</svg>\
            </div>\
          </div>\
        </div>\
\
\
        <div id="s-Image_5" class="pie image lockV firer ie-background commentable non-processed" customid="Arrow_right"   datasizewidth="42.0px" datasizeheight="42.0px" dataX="981.0" dataY="567.0" aspectRatio="1.0"  rotationdeg="180" alt="image" systemName="./images/5b44096b-988d-4225-a568-1bdd21ca9fc1.svg" overlay="">\
          <div class="borderLayer">\
          	<div class="imageViewport">\
            	<?xml version="1.0" encoding="UTF-8"?>\
            	<svg preserveAspectRatio=\'none\' width="68px" height="68px" viewBox="0 0 68 68" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink">\
            	    <!-- Generator: Sketch 49.3 (51167) - http://www.bohemiancoding.com/sketch -->\
            	    <title>Stroked Arrow Left</title>\
            	    <desc>Created with Sketch.</desc>\
            	    <defs></defs>\
            	    <g id="s-Image_5-Page-1" stroke="none" stroke-width="1" fill="none" fill-rule="evenodd">\
            	        <g id="Slider-#9" transform="translate(-98.000000, -243.000000)">\
            	            <g id="s-Image_5-Stroked-Arrow-Left" transform="translate(99.000000, 244.000000)">\
            	                <circle id="s-Image_5-Stroke" stroke="#CBCBCB" cx="33" cy="33" r="33"></circle>\
            	                <g id="s-Image_5-Arrow-Left" transform="translate(23.000000, 19.000000)" fill="#CBCBCB">\
            	                    <polyline transform="translate(8.000000, 14.000000) scale(-1, 1) translate(-8.000000, -14.000000) " points="1.157 0 0 1.144 12.325 13.62 0 25.691 1.325 27 15 13.691 1.157 0"></polyline>\
            	                </g>\
            	            </g>\
            	        </g>\
            	    </g>\
            	</svg>\
            </div>\
          </div>\
        </div>\
\
      </div>\
\
\
      <div id="s-Image_6" class="pie image firer ie-background commentable non-processed" customid="Image"   datasizewidth="257.0px" datasizeheight="263.0px" dataX="774.0" dataY="229.0"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/8d38f13e-ec02-4e86-87bd-73bce1a49b23.jpg" />\
        	</div>\
        </div>\
      </div>\
\
      <div id="s-Paragraph_10" class="pie richtext manualfit firer ie-background commentable non-processed" customid="Paragraph_1"   datasizewidth="400.0px" datasizeheight="168.0px" dataX="147.7" dataY="386.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_10_0">Caracter&iacute;sticas:<br />.Cocina<br />.Ba&ntilde;o<br />.Terraza<br />.Sal&oacute;n<br />.Ascensor<br />.Limpieza</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Paragraph_11" class="pie richtext manualfit firer ie-background commentable non-processed" customid="Paragraph_1"   datasizewidth="400.0px" datasizeheight="168.0px" dataX="348.0" dataY="386.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Paragraph_11_0">Contacto:<br />Tlf: +34 666666666<br />Email: contacto@piso.com<br />P&aacute;gina: paginaejemplo.com</span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;