(function(window, undefined) {

  var jimLinks = {
    "f36535a0-601e-4140-9afd-cb881cbd51bd" : {
      "Paragraph_5" : [
        "00467d17-fd92-48fd-9953-44af524f962f"
      ],
      "Rectangle_3" : [
        "00467d17-fd92-48fd-9953-44af524f962f"
      ]
    },
    "13041a79-d2cb-4c73-a076-03852a6d4caf" : {
      "Paragraph_5" : [
        "00467d17-fd92-48fd-9953-44af524f962f"
      ],
      "Rectangle_5" : [
        "75e1b7fb-c27f-4b2e-8283-0894efb179f1"
      ]
    },
    "75e1b7fb-c27f-4b2e-8283-0894efb179f1" : {
    },
    "d12245cc-1680-458d-89dd-4f0d7fb22724" : {
      "Rectangle_2" : [
        "f36535a0-601e-4140-9afd-cb881cbd51bd"
      ]
    },
    "00467d17-fd92-48fd-9953-44af524f962f" : {
      "Image_4" : [
        "13041a79-d2cb-4c73-a076-03852a6d4caf"
      ]
    }    
  }

  window.jimLinks = jimLinks;
})(window);