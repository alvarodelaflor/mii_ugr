var content='<div class="ui-page" deviceName="androidphone" deviceType="mobile" deviceWidth="412" deviceHeight="732">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devMobile canvas firer commentable non-processed" alignment="left" name="Template 1" width="412" height="732">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1607879148793.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1607879148793-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><![endif]-->\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
\
    <div id="s-7821f0ac-14c0-4671-bfa0-218884fa6abb" class="screen growth-vertical devMobile canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="Home" width="412" height="732">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/7821f0ac-14c0-4671-bfa0-218884fa6abb-1607879148793.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/screens/7821f0ac-14c0-4671-bfa0-218884fa6abb-1607879148793-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/screens/7821f0ac-14c0-4671-bfa0-218884fa6abb-1607879148793-ie8.css" /><![endif]-->\
      <div class="freeLayout">\
      <div id="s-Image_1" class="pie image firer ie-background commentable non-processed" customid="Image 1"   datasizewidth="412.0px" datasizeheight="732.0px" dataX="0.0" dataY="0.0"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/926ef9ec-540e-47ce-ae34-83a6bae5aed7.png" />\
        	</div>\
        </div>\
      </div>\
\
      <div id="s-Hotspot_1" class="imagemap firer click ie-background commentable non-processed" customid="Hotspot 1"   datasizewidth="154.0px" datasizeheight="40.0px" dataX="98.0" dataY="533.0"  >\
        <div class="clickableSpot"></div>\
      </div>\
      <div id="s-Hotspot_2" class="imagemap firer click ie-background commentable non-processed" customid="Hotspot 2"   datasizewidth="146.0px" datasizeheight="46.0px" dataX="106.0" dataY="593.0"  >\
        <div class="clickableSpot"></div>\
      </div>\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;