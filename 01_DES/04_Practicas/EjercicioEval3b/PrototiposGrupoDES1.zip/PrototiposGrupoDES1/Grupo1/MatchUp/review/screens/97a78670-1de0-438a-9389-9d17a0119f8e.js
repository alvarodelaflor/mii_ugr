var content='<div class="ui-page" deviceName="androidphone" deviceType="mobile" deviceWidth="412" deviceHeight="732">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devMobile canvas firer commentable non-processed" alignment="left" name="Template 1" width="412" height="732">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1607879148793.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1607879148793-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><![endif]-->\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
\
    <div id="s-97a78670-1de0-438a-9389-9d17a0119f8e" class="screen growth-vertical devMobile canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="B&uacute;squeda" width="412" height="732">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/97a78670-1de0-438a-9389-9d17a0119f8e-1607879148793.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/screens/97a78670-1de0-438a-9389-9d17a0119f8e-1607879148793-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/screens/97a78670-1de0-438a-9389-9d17a0119f8e-1607879148793-ie8.css" /><![endif]-->\
      <div class="freeLayout">\
      <div id="s-Image_1" class="pie image firer ie-background commentable non-processed" customid="Image 1"   datasizewidth="377.0px" datasizeheight="682.0px" dataX="20.0" dataY="20.0"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/d6f7845e-c121-45f7-b086-b5fe11dfa776.png" />\
        	</div>\
        </div>\
      </div>\
\
\
      <div id="s-Image_2" class="pie image firer ie-background commentable non-processed" customid="Image 2"   datasizewidth="412.0px" datasizeheight="732.0px" dataX="-0.0" dataY="0.0"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/81afa404-e6b9-4886-8e9c-9b787108d8e4.png" />\
        	</div>\
        </div>\
      </div>\
\
      <div id="s-Hotspot_1" class="imagemap firer click ie-background commentable non-processed" customid="Hotspot 1"   datasizewidth="48.0px" datasizeheight="67.0px" dataX="-0.0" dataY="0.0"  >\
        <div class="clickableSpot"></div>\
      </div>\
      <div id="s-Hotspot_2" class="imagemap firer click ie-background commentable non-processed" customid="Hotspot 2"   datasizewidth="164.0px" datasizeheight="52.0px" dataX="126.0" dataY="575.0"  >\
        <div class="clickableSpot"></div>\
      </div>\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;