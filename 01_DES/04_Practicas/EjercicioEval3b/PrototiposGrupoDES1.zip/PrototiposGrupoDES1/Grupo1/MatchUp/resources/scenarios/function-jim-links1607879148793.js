(function(window, undefined) {

  var jimLinks = {
    "cef460d0-fa5e-486b-b2d9-23116e9f989b" : {
      "Hotspot_1" : [
        "cbc720d4-a35a-4653-8802-87a92004ca2b"
      ],
      "Hotspot_2" : [
        "18ceeb5b-ae43-4e84-9bdf-eaa91bade1fc"
      ],
      "Hotspot_3" : [
        "cef460d0-fa5e-486b-b2d9-23116e9f989b"
      ],
      "Hotspot_4" : [
        "3cbbbf72-afa9-46d9-8aa5-4a8ee9fa9bce"
      ]
    },
    "cbc720d4-a35a-4653-8802-87a92004ca2b" : {
      "Hotspot_1" : [
        "a304b4a5-a8f3-4e3f-ba3d-bacf670b4658"
      ],
      "Hotspot_2" : [
        "de5cd936-fddb-4696-b13c-779246e826f2"
      ],
      "Hotspot_3" : [
        "cbc720d4-a35a-4653-8802-87a92004ca2b"
      ],
      "Hotspot_4" : [
        "18ceeb5b-ae43-4e84-9bdf-eaa91bade1fc"
      ],
      "Hotspot_5" : [
        "cef460d0-fa5e-486b-b2d9-23116e9f989b"
      ],
      "Hotspot_6" : [
        "97a78670-1de0-438a-9389-9d17a0119f8e"
      ]
    },
    "de5cd936-fddb-4696-b13c-779246e826f2" : {
      "Hotspot_1" : [
        "cbc720d4-a35a-4653-8802-87a92004ca2b"
      ]
    },
    "3cbbbf72-afa9-46d9-8aa5-4a8ee9fa9bce" : {
      "Hotspot_1" : [
        "cef460d0-fa5e-486b-b2d9-23116e9f989b"
      ]
    },
    "97a78670-1de0-438a-9389-9d17a0119f8e" : {
      "Hotspot_1" : [
        "cbc720d4-a35a-4653-8802-87a92004ca2b"
      ],
      "Hotspot_2" : [
        "cbc720d4-a35a-4653-8802-87a92004ca2b"
      ]
    },
    "686aeb0f-a8cf-4e80-86bc-6edeb8922e76" : {
      "Hotspot_1" : [
        "0cf44d35-3e60-4338-8733-cfe251f28e85"
      ],
      "Hotspot_2" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Hotspot_3" : [
        "cbc720d4-a35a-4653-8802-87a92004ca2b"
      ]
    },
    "a304b4a5-a8f3-4e3f-ba3d-bacf670b4658" : {
      "Hotspot_1" : [
        "cbc720d4-a35a-4653-8802-87a92004ca2b"
      ]
    },
    "0cf44d35-3e60-4338-8733-cfe251f28e85" : {
      "Hotspot_1" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Hotspot_2" : [
        "cbc720d4-a35a-4653-8802-87a92004ca2b"
      ],
      "Hotspot_3" : [
        "686aeb0f-a8cf-4e80-86bc-6edeb8922e76"
      ]
    },
    "18ceeb5b-ae43-4e84-9bdf-eaa91bade1fc" : {
      "Hotspot_1" : [
        "a304b4a5-a8f3-4e3f-ba3d-bacf670b4658"
      ],
      "Hotspot_2" : [
        "cef460d0-fa5e-486b-b2d9-23116e9f989b"
      ],
      "Hotspot_3" : [
        "cef460d0-fa5e-486b-b2d9-23116e9f989b"
      ],
      "Hotspot_4" : [
        "18ceeb5b-ae43-4e84-9bdf-eaa91bade1fc"
      ],
      "Hotspot_5" : [
        "cbc720d4-a35a-4653-8802-87a92004ca2b"
      ],
      "Hotspot_6" : [
        "97a78670-1de0-438a-9389-9d17a0119f8e"
      ]
    },
    "d12245cc-1680-458d-89dd-4f0d7fb22724" : {
      "Hotspot_1" : [
        "cbc720d4-a35a-4653-8802-87a92004ca2b"
      ],
      "Hotspot_2" : [
        "0cf44d35-3e60-4338-8733-cfe251f28e85"
      ]
    },
    "7821f0ac-14c0-4671-bfa0-218884fa6abb" : {
      "Hotspot_1" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Hotspot_2" : [
        "cbc720d4-a35a-4653-8802-87a92004ca2b"
      ]
    }    
  }

  window.jimLinks = jimLinks;
})(window);