(function(window, undefined) {

  var jimLinks = {
    "9c1b6c9f-0dd1-4cd7-9aec-36da4a3af3b1" : {
      "Hotspot_1" : [
        "4b2d2c62-05d8-4b6c-af44-096758a9b901"
      ],
      "Hotspot_2" : [
        "4b2d2c62-05d8-4b6c-af44-096758a9b901"
      ]
    },
    "eaaff426-e627-415e-8efe-66c5c3668847" : {
      "Hotspot_1" : [
        "4b2d2c62-05d8-4b6c-af44-096758a9b901"
      ],
      "Hotspot_2" : [
        "73e8cfd3-93a9-47c0-ba75-6c011f58ee1e"
      ],
      "Hotspot_3" : [
        "eaaff426-e627-415e-8efe-66c5c3668847"
      ],
      "Hotspot_4" : [
        "2109c6ab-c6a4-4eb1-b48e-0c1e88dd6011"
      ]
    },
    "4b2d2c62-05d8-4b6c-af44-096758a9b901" : {
      "Hotspot_1" : [
        "73e8cfd3-93a9-47c0-ba75-6c011f58ee1e"
      ],
      "Hotspot_2" : [
        "9c1b6c9f-0dd1-4cd7-9aec-36da4a3af3b1"
      ],
      "Hotspot_3" : [
        "726e57f6-8abb-4b1a-aeea-d991886925cb"
      ],
      "Hotspot_4" : [
        "726e57f6-8abb-4b1a-aeea-d991886925cb"
      ],
      "Hotspot_5" : [
        "726e57f6-8abb-4b1a-aeea-d991886925cb"
      ],
      "Hotspot_6" : [
        "45bf0b3e-fd98-41ad-a7c0-d3535ddffdfd"
      ]
    },
    "726e57f6-8abb-4b1a-aeea-d991886925cb" : {
      "Hotspot_1" : [
        "4b2d2c62-05d8-4b6c-af44-096758a9b901"
      ],
      "Hotspot_2" : [
        "9c1b6c9f-0dd1-4cd7-9aec-36da4a3af3b1"
      ],
      "Hotspot_3" : [
        "4b2d2c62-05d8-4b6c-af44-096758a9b901"
      ],
      "Hotspot_4" : [
        "45bf0b3e-fd98-41ad-a7c0-d3535ddffdfd"
      ]
    },
    "45bf0b3e-fd98-41ad-a7c0-d3535ddffdfd" : {
      "Hotspot_1" : [
        "4b2d2c62-05d8-4b6c-af44-096758a9b901"
      ],
      "Hotspot_2" : [
        "18355e63-5e82-4cf7-8e25-10f790d50c03"
      ],
      "Hotspot_3" : [
        "4b2d2c62-05d8-4b6c-af44-096758a9b901"
      ]
    },
    "2109c6ab-c6a4-4eb1-b48e-0c1e88dd6011" : {
      "Hotspot_1" : [
        "4b2d2c62-05d8-4b6c-af44-096758a9b901"
      ],
      "Hotspot_2" : [
        "4b2d2c62-05d8-4b6c-af44-096758a9b901"
      ],
      "Hotspot_3" : [
        "73e8cfd3-93a9-47c0-ba75-6c011f58ee1e"
      ],
      "Hotspot_4" : [
        "eaaff426-e627-415e-8efe-66c5c3668847"
      ],
      "Hotspot_5" : [
        "2109c6ab-c6a4-4eb1-b48e-0c1e88dd6011"
      ]
    },
    "73e8cfd3-93a9-47c0-ba75-6c011f58ee1e" : {
      "Hotspot_1" : [
        "73e8cfd3-93a9-47c0-ba75-6c011f58ee1e"
      ],
      "Hotspot_2" : [
        "eaaff426-e627-415e-8efe-66c5c3668847"
      ],
      "Hotspot_3" : [
        "2109c6ab-c6a4-4eb1-b48e-0c1e88dd6011"
      ],
      "Hotspot_4" : [
        "4b2d2c62-05d8-4b6c-af44-096758a9b901"
      ],
      "Hotspot_5" : [
        "4b2d2c62-05d8-4b6c-af44-096758a9b901"
      ],
      "Hotspot_6" : [
        "4b2d2c62-05d8-4b6c-af44-096758a9b901"
      ]
    },
    "d12245cc-1680-458d-89dd-4f0d7fb22724" : {
      "Hotspot_1" : [
        "73e8cfd3-93a9-47c0-ba75-6c011f58ee1e"
      ]
    },
    "18355e63-5e82-4cf7-8e25-10f790d50c03" : {
      "Hotspot_1" : [
        "45bf0b3e-fd98-41ad-a7c0-d3535ddffdfd"
      ]
    }    
  }

  window.jimLinks = jimLinks;
})(window);