var content='<div class="ui-page" deviceName="androidphone" deviceType="mobile" deviceWidth="360" deviceHeight="640">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devMobile canvas firer commentable non-processed" alignment="left" name="Template 1" width="360" height="640">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1607565870773.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1607565870773-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><![endif]-->\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
\
    <div id="s-2109c6ab-c6a4-4eb1-b48e-0c1e88dd6011" class="screen growth-vertical devMobile canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="Agendas-TiempoLibre" width="360" height="640">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/2109c6ab-c6a4-4eb1-b48e-0c1e88dd6011-1607565870773.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/screens/2109c6ab-c6a4-4eb1-b48e-0c1e88dd6011-1607565870773-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/screens/2109c6ab-c6a4-4eb1-b48e-0c1e88dd6011-1607565870773-ie8.css" /><![endif]-->\
      <div class="freeLayout">\
      <div id="s-Image_1" class="pie image firer ie-background commentable non-processed" customid="Image 1"   datasizewidth="360.0px" datasizeheight="596.5px" dataX="0.0" dataY="0.0"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/6f00adb2-ebef-46fa-acb4-261eea4e7217.jpg" />\
        	</div>\
        </div>\
      </div>\
\
      <div id="s-Hotspot_1" class="imagemap firer click ie-background commentable non-processed" customid="Hotspot 5"   datasizewidth="238.0px" datasizeheight="71.3px" dataX="46.5" dataY="219.0"  >\
        <div class="clickableSpot"></div>\
      </div>\
      <div id="s-Hotspot_2" class="imagemap firer click ie-background commentable non-processed" customid="Hotspot 6"   datasizewidth="238.0px" datasizeheight="71.3px" dataX="46.5" dataY="298.2"  >\
        <div class="clickableSpot"></div>\
      </div>\
      <div id="s-Hotspot_3" class="imagemap firer click ie-background commentable non-processed" customid="Hotspot 7"   datasizewidth="105.0px" datasizeheight="41.0px" dataX="10.0" dataY="68.0"  >\
        <div class="clickableSpot"></div>\
      </div>\
      <div id="s-Hotspot_4" class="imagemap firer click ie-background commentable non-processed" customid="Hotspot 8"   datasizewidth="78.0px" datasizeheight="37.0px" dataX="136.0" dataY="72.0"  >\
        <div class="clickableSpot"></div>\
      </div>\
      <div id="s-Hotspot_5" class="imagemap firer click ie-background commentable non-processed" customid="Hotspot 9"   datasizewidth="123.0px" datasizeheight="33.0px" dataX="227.0" dataY="68.0"  >\
        <div class="clickableSpot"></div>\
      </div>\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;