document.write("<script type='text/javascript' charset='utf-8' src='./resources/jim/javascript/jim-min.js'></script>");
document.write("<script type='text/javascript' charset='utf-8' src='./resources/scenarios/function-jim-links1607565870773.js'></script>");
document.write("<script type='text/javascript' charset='utf-8' src='./resources/jim/javascript/mobile/custom/jim-custom-min.js'></script>");
document.write("<script type='text/javascript' charset='utf-8' src='./resources/scroll-1607565870773.js'></script>");
document.write("<script type='text/javascript' charset='utf-8' src='./resources/prototype-1607565870773.js'></script>");