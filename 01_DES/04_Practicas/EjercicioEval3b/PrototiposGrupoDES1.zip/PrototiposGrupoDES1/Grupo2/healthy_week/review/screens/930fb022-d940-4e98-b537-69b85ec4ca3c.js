var content='<div class="ui-page" deviceName="androidphone" deviceType="mobile" deviceWidth="360" deviceHeight="869">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devMobile canvas firer commentable non-processed" alignment="left" name="Template 1" width="360" height="640">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1607784095648.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1607784095648-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><![endif]-->\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
\
    <div id="s-930fb022-d940-4e98-b537-69b85ec4ca3c" class="screen growth-vertical devMobile canvas PORTRAIT firer ie-background commentable non-processed" alignment="center" name="Publicar_receta" width="360" height="869">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/930fb022-d940-4e98-b537-69b85ec4ca3c-1607784095648.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/screens/930fb022-d940-4e98-b537-69b85ec4ca3c-1607784095648-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/screens/930fb022-d940-4e98-b537-69b85ec4ca3c-1607784095648-ie8.css" /><![endif]-->\
      <div class="freeLayout">\
      <div id="s-Image_1" class="pie image firer ie-background commentable non-processed" customid="Image 1"   datasizewidth="360.0px" datasizeheight="869.8px" dataX="0.0" dataY="0.0"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/dc204258-3abb-4de0-87de-9cd26c45d4ec.png" />\
        	</div>\
        </div>\
      </div>\
\
      <div id="s-Hotspot_1" class="imagemap firer click ie-background commentable non-processed" customid="Hotspot 1"   datasizewidth="62.0px" datasizeheight="67.0px" dataX="0.0" dataY="-0.0"  >\
        <div class="clickableSpot"></div>\
      </div>\
      <div id="s-Rectangle_1" class="pie rectangle manualfit firer commentable hidden non-processed" customid="Rectangle"   datasizewidth="360.0px" datasizeheight="866.1px" datasizewidthpx="359.99999999999994" datasizeheightpx="866.0994124302033" dataX="0.0" dataY="-0.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_1_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
      <div id="s-Hotspot_2" class="imagemap firer click ie-background commentable non-processed" customid="Hotspot 2"   datasizewidth="51.0px" datasizeheight="53.0px" dataX="41.0" dataY="191.0"  >\
        <div class="clickableSpot"></div>\
      </div>\
\
      <div id="s-Image_2" class="pie image firer ie-background commentable hidden non-processed" customid="Image"   datasizewidth="360.0px" datasizeheight="416.0px" dataX="0.0" dataY="453.8"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/596dd2de-6a63-43e4-876f-b346a540c0fa.png" />\
        	</div>\
        </div>\
      </div>\
\
      <div id="s-Hotspot_3" class="imagemap firer click ie-background commentable hidden non-processed" customid="Hotspot 3"   datasizewidth="88.0px" datasizeheight="108.0px" dataX="31.0" dataY="485.0"  >\
        <div class="clickableSpot"></div>\
      </div>\
      <div id="s-Hotspot_4" class="imagemap firer click ie-background commentable hidden non-processed" customid="Hotspot 4"   datasizewidth="94.0px" datasizeheight="108.0px" dataX="146.0" dataY="485.0"  >\
        <div class="clickableSpot"></div>\
      </div>\
      <div id="s-Hotspot_5" class="imagemap firer click ie-background commentable hidden non-processed" customid="Hotspot 5"   datasizewidth="75.0px" datasizeheight="108.0px" dataX="256.0" dataY="485.0"  >\
        <div class="clickableSpot"></div>\
      </div>\
      <div id="s-Hotspot_6" class="imagemap firer click ie-background commentable hidden non-processed" customid="Hotspot 5"   datasizewidth="94.0px" datasizeheight="108.0px" dataX="31.0" dataY="620.0"  >\
        <div class="clickableSpot"></div>\
      </div>\
      <div id="s-Hotspot_7" class="imagemap firer click ie-background commentable hidden non-processed" customid="Hotspot 5"   datasizewidth="84.0px" datasizeheight="120.7px" dataX="156.0" dataY="607.3"  >\
        <div class="clickableSpot"></div>\
      </div>\
      <div id="s-Hotspot_8" class="imagemap firer click ie-background commentable hidden non-processed" customid="Hotspot 5"   datasizewidth="64.0px" datasizeheight="108.0px" dataX="266.5" dataY="607.3"  >\
        <div class="clickableSpot"></div>\
      </div>\
      <div id="s-Hotspot_9" class="imagemap firer click ie-background commentable hidden non-processed" customid="Hotspot 5"   datasizewidth="74.0px" datasizeheight="108.0px" dataX="45.0" dataY="749.0"  >\
        <div class="clickableSpot"></div>\
      </div>\
      <div id="s-Hotspot_10" class="imagemap firer click ie-background commentable hidden non-processed" customid="Hotspot 5"   datasizewidth="80.0px" datasizeheight="118.0px" dataX="160.0" dataY="739.0"  >\
        <div class="clickableSpot"></div>\
      </div>\
      <div id="s-Hotspot_11" class="imagemap firer click ie-background commentable hidden non-processed" customid="Hotspot 5"   datasizewidth="65.0px" datasizeheight="97.0px" dataX="266.0" dataY="739.0"  >\
        <div class="clickableSpot"></div>\
      </div>\
      <div id="s-Hotspot_12" class="imagemap firer click ie-background commentable non-processed" customid="Hotspot 12"   datasizewidth="63.5px" datasizeheight="27.0px" dataX="215.0" dataY="407.9"  >\
        <div class="clickableSpot"></div>\
      </div>\
      <div id="s-Hotspot_13" class="imagemap firer click ie-background commentable non-processed" customid="Hotspot 13"   datasizewidth="108.5px" datasizeheight="29.0px" dataX="190.0" dataY="257.0"  >\
        <div class="clickableSpot"></div>\
      </div>\
      <div id="s-Hotspot_14" class="imagemap firer click ie-background commentable non-processed" customid="Hotspot 14"   datasizewidth="100.0px" datasizeheight="39.0px" dataX="206.0" dataY="446.0"  >\
        <div class="clickableSpot"></div>\
      </div>\
      <div id="s-Hotspot_15" class="imagemap firer click ie-background commentable non-processed" customid="Hotspot 15"   datasizewidth="100.0px" datasizeheight="38.0px" dataX="119.0" dataY="798.0"  >\
        <div class="clickableSpot"></div>\
      </div>\
      <div id="s-Hotspot_16" class="imagemap firer click ie-background commentable non-processed" customid="Hotspot 16"   datasizewidth="63.5px" datasizeheight="28.0px" dataX="215.0" dataY="749.0"  >\
        <div class="clickableSpot"></div>\
      </div>\
\
      <div id="s-Image_3" class="pie image firer ie-background commentable hidden non-processed" customid="Image"   datasizewidth="222.0px" datasizeheight="205.0px" dataX="69.0" dataY="332.4"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/dfe9250d-6300-44f4-85ec-9b9cba688643.png" />\
        	</div>\
        </div>\
      </div>\
\
\
      <div id="s-Image_4" class="pie image firer ie-background commentable hidden non-processed" customid="Image"   datasizewidth="252.0px" datasizeheight="224.0px" dataX="62.0" dataY="322.9"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/e736ebf8-fb64-41c3-b26f-ac426a916307.png" />\
        	</div>\
        </div>\
      </div>\
\
\
      <div id="s-Image_5" class="pie image firer ie-background commentable hidden non-processed" customid="Image"   datasizewidth="131.0px" datasizeheight="253.0px" dataX="106.5" dataY="307.0"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/dd0edeec-90de-4d1d-82be-2a05fd68c9fe.png" />\
        	</div>\
        </div>\
      </div>\
\
\
      <div id="s-Image_6" class="pie image firer ie-background commentable hidden non-processed" customid="Image"   datasizewidth="329.0px" datasizeheight="174.0px" dataX="15.5" dataY="398.0"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/242b15ba-5bd2-4d0d-8855-4d48262ed8dd.png" />\
        	</div>\
        </div>\
      </div>\
\
      <div id="s-Hotspot_17" class="imagemap firer click ie-background commentable hidden non-processed" customid="Hotspot 17"   datasizewidth="100.0px" datasizeheight="239.0px" dataX="121.5" dataY="321.0"  >\
        <div class="clickableSpot"></div>\
      </div>\
      <div id="s-Hotspot_18" class="imagemap firer click ie-background commentable hidden non-processed" customid="Hotspot 18"   datasizewidth="193.0px" datasizeheight="184.0px" dataX="83.0" dataY="341.9"  >\
        <div class="clickableSpot"></div>\
      </div>\
      <div id="s-Hotspot_19" class="imagemap firer click ie-background commentable hidden non-processed" customid="Hotspot 19"   datasizewidth="137.0px" datasizeheight="47.5px" dataX="124.5" dataY="491.5"  >\
        <div class="clickableSpot"></div>\
      </div>\
      <div id="s-Hotspot_20" class="imagemap firer click ie-background commentable hidden non-processed" customid="Hotspot 20"   datasizewidth="227.0px" datasizeheight="196.0px" dataX="72.0" dataY="336.9"  >\
        <div class="clickableSpot"></div>\
      </div>\
\
      <div id="s-Image_7" class="pie image firer ie-background commentable hidden non-processed" customid="Image"   datasizewidth="308.0px" datasizeheight="216.9px" dataX="26.0" dataY="286.0"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/5f0c298d-99e4-457d-a50f-8286bea66861.png" />\
        	</div>\
        </div>\
      </div>\
\
\
      <div id="s-Image_8" class="pie image firer ie-background commentable hidden non-processed" customid="Image"   datasizewidth="360.0px" datasizeheight="218.0px" dataX="0.0" dataY="286.0"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/6a877992-66b5-4c69-a32c-60f1c4d3a878.png" />\
        	</div>\
        </div>\
      </div>\
\
      <div id="s-Hotspot_21" class="imagemap firer click ie-background commentable hidden non-processed" customid="Hotspot 21"   datasizewidth="121.0px" datasizeheight="66.0px" dataX="100.0" dataY="410.0"  >\
        <div class="clickableSpot"></div>\
      </div>\
      <div id="s-Hotspot_22" class="imagemap firer click ie-background commentable hidden non-processed" customid="Hotspot 22"   datasizewidth="87.0px" datasizeheight="41.5px" dataX="54.0" dataY="421.5"  >\
        <div class="clickableSpot"></div>\
      </div>\
      <div id="s-Hotspot_23" class="imagemap firer click ie-background commentable hidden non-processed" customid="Hotspot 23"   datasizewidth="109.0px" datasizeheight="41.5px" dataX="180.0" dataY="421.5"  >\
        <div class="clickableSpot"></div>\
      </div>\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;