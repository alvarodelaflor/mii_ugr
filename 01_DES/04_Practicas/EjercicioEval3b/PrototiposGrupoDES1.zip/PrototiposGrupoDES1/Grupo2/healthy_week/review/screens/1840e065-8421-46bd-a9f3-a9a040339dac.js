var content='<div class="ui-page" deviceName="androidphone" deviceType="mobile" deviceWidth="360" deviceHeight="640">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devMobile canvas firer commentable non-processed" alignment="left" name="Template 1" width="360" height="640">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1607784095648.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1607784095648-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><![endif]-->\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
\
    <div id="s-1840e065-8421-46bd-a9f3-a9a040339dac" class="screen growth-vertical devMobile canvas PORTRAIT firer ie-background commentable non-processed" alignment="left" name="Informaci&oacute;n_receta_hacer_men&uacute;" width="360" height="640">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/1840e065-8421-46bd-a9f3-a9a040339dac-1607784095648.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/screens/1840e065-8421-46bd-a9f3-a9a040339dac-1607784095648-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/screens/1840e065-8421-46bd-a9f3-a9a040339dac-1607784095648-ie8.css" /><![endif]-->\
      <div class="freeLayout">\
      <div id="s-Image_1" class="pie image firer pageload ie-background commentable non-processed" customid="Image 1"   datasizewidth="360.0px" datasizeheight="640.0px" dataX="0.0" dataY="0.0"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/1137ef65-6f29-41af-8fad-944eef6a4785.png" />\
        	</div>\
        </div>\
      </div>\
\
      <div id="s-Hotspot_1" class="imagemap firer click ie-background commentable non-processed" customid="Hotspot 1"   datasizewidth="69.0px" datasizeheight="77.0px" dataX="269.0" dataY="553.0"  >\
        <div class="clickableSpot"></div>\
      </div>\
      <div id="s-Hotspot_2" class="imagemap firer click ie-background commentable non-processed" customid="Hotspot 2"   datasizewidth="117.0px" datasizeheight="47.0px" dataX="133.0" dataY="304.0"  >\
        <div class="clickableSpot"></div>\
      </div>\
      <div id="s-Hotspot_3" class="imagemap firer click ie-background commentable non-processed" customid="Hotspot 3"   datasizewidth="64.0px" datasizeheight="47.0px" dataX="260.0" dataY="304.0"  >\
        <div class="clickableSpot"></div>\
      </div>\
      <div id="s-Hotspot_4" class="imagemap firer click ie-background commentable non-processed" customid="Hotspot 4"   datasizewidth="42.0px" datasizeheight="43.0px" dataX="11.0" dataY="10.0"  >\
        <div class="clickableSpot"></div>\
      </div>\
      <div id="s-Rectangle_1" class="pie rectangle manualfit firer click commentable non-processed" customid="Rectangle"   datasizewidth="360.0px" datasizeheight="638.0px" datasizewidthpx="359.9999999999999" datasizeheightpx="637.9999999999999" dataX="0.0" dataY="2.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_1_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Image_2" class="pie image firer ie-background commentable non-processed" customid="Image 3"   datasizewidth="314.0px" datasizeheight="194.0px" dataX="23.0" dataY="200.0"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/b4e85a73-3040-4748-8e48-38fc3c399d4f.png" />\
        	</div>\
        </div>\
      </div>\
\
      <div id="s-Hotspot_5" class="imagemap firer click ie-background commentable non-processed" customid="Hotspot 6"   datasizewidth="130.0px" datasizeheight="46.0px" dataX="126.5" dataY="312.0"  >\
        <div class="clickableSpot"></div>\
      </div>\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;