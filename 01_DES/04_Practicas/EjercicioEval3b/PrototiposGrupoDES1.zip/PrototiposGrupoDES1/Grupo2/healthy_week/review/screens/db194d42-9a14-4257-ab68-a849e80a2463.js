var content='<div class="ui-page" deviceName="androidphone" deviceType="mobile" deviceWidth="360" deviceHeight="624">\
    <div id="t-f39803f7-df02-4169-93eb-7547fb8c961a" class="template growth-both devMobile canvas firer commentable non-processed" alignment="left" name="Template 1" width="360" height="640">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1607784095648.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/templates/f39803f7-df02-4169-93eb-7547fb8c961a-1607784095648-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><![endif]-->\
      <div class="freeLayout">\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
\
    <div id="s-db194d42-9a14-4257-ab68-a849e80a2463" class="screen growth-vertical devMobile canvas PORTRAIT firer ie-background commentable non-processed" alignment="center" name="Filtro_receta" width="360" height="624">\
    <div id="backgroundBox"><div class="colorLayer"></div><div class="imageLayer"></div></div>\
    <div id="alignmentBox">\
      <link type="text/css" rel="stylesheet" href="./resources/screens/db194d42-9a14-4257-ab68-a849e80a2463-1607784095648.css" />\
      <!--[if IE]><link type="text/css" rel="stylesheet" href="./resources/screens/db194d42-9a14-4257-ab68-a849e80a2463-1607784095648-ie.css" /><![endif]-->\
      <!--[if lte IE 8]><link type="text/css" rel="stylesheet" href="./resources/screens/db194d42-9a14-4257-ab68-a849e80a2463-1607784095648-ie8.css" /><![endif]-->\
      <div class="freeLayout">\
      <div id="s-Image_1" class="pie image firer click ie-background commentable non-processed" customid="Image 1"   datasizewidth="360.0px" datasizeheight="624.1px" dataX="0.0" dataY="0.0"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/ef617ded-46f3-4522-91d9-3e7fa445d32d.png" />\
        	</div>\
        </div>\
      </div>\
\
      <div id="s-Hotspot_1" class="imagemap firer click ie-background commentable non-processed" customid="Hotspot 1"   datasizewidth="88.0px" datasizeheight="23.0px" dataX="180.0" dataY="104.0"  >\
        <div class="clickableSpot"></div>\
      </div>\
      <div id="s-Hotspot_2" class="imagemap firer click ie-background commentable non-processed" customid="Hotspot 2"   datasizewidth="53.0px" datasizeheight="80.0px" dataX="11.0" dataY="11.0"  >\
        <div class="clickableSpot"></div>\
      </div>\
      <div id="s-Rectangle_1" class="pie rectangle manualfit firer commentable hidden non-processed" customid="Rectangle"   datasizewidth="360.0px" datasizeheight="614.9px" datasizewidthpx="360.0" datasizeheightpx="614.892600140979" dataX="0.0" dataY="-0.0" >\
        <div class="backgroundLayer">\
          <div class="colorLayer"></div>\
          <div class="imageLayer"></div>\
        </div>\
        <div class="borderLayer">\
          <div class="paddingLayer">\
            <div class="content">\
              <div class="valign">\
                <span id="rtr-s-Rectangle_1_0"></span>\
              </div>\
            </div>\
          </div>\
        </div>\
      </div>\
\
      <div id="s-Image_2" class="pie image firer ie-background commentable hidden non-processed" customid="Image"   datasizewidth="186.0px" datasizeheight="138.0px" dataX="87.0" dataY="188.6"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/a6f2329c-ebe1-43d6-88e7-1da3e61a71fb.png" />\
        	</div>\
        </div>\
      </div>\
\
      <div id="s-Hotspot_3" class="imagemap firer click ie-background commentable non-processed" customid="Hotspot 4"   datasizewidth="167.0px" datasizeheight="108.9px" dataX="96.5" dataY="203.1"  >\
        <div class="clickableSpot"></div>\
      </div>\
      <div id="s-Hotspot_4" class="imagemap firer click ie-background commentable non-processed" customid="Hotspot 5"   datasizewidth="88.0px" datasizeheight="33.0px" dataX="180.0" dataY="151.0"  >\
        <div class="clickableSpot"></div>\
      </div>\
      <div id="s-Hotspot_5" class="imagemap firer click ie-background commentable non-processed" customid="Hotspot 3"   datasizewidth="65.0px" datasizeheight="41.0px" dataX="194.0" dataY="254.0"  >\
        <div class="clickableSpot"></div>\
      </div>\
\
      <div id="s-Image_3" class="pie image firer ie-background commentable hidden non-processed" customid="Image"   datasizewidth="255.0px" datasizeheight="163.0px" dataX="53.0" dataY="176.1"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/6b390ac1-3c3f-4cee-a4c2-65a564a093e9.png" />\
        	</div>\
        </div>\
      </div>\
\
\
      <div id="s-Image_4" class="pie image firer ie-background commentable hidden non-processed" customid="Image"   datasizewidth="100.0px" datasizeheight="233.4px" dataX="130.0" dataY="195.4"   alt="image">\
        <div class="borderLayer">\
        	<div class="imageViewport">\
        		<img src="./images/afdfaa7c-b8e6-444e-a86f-94f4d5c93668.png" />\
        	</div>\
        </div>\
      </div>\
\
      <div id="s-Hotspot_6" class="imagemap firer click ie-background commentable hidden non-processed" customid="Hotspot 6"   datasizewidth="224.0px" datasizeheight="136.5px" dataX="68.0" dataY="189.3"  >\
        <div class="clickableSpot"></div>\
      </div>\
      <div id="s-Hotspot_7" class="imagemap firer click ie-background commentable hidden non-processed" customid="Hotspot 7"   datasizewidth="90.5px" datasizeheight="228.8px" dataX="134.8" dataY="197.7"  >\
        <div class="clickableSpot"></div>\
      </div>\
      <div id="s-Hotspot_8" class="imagemap firer click ie-background commentable non-processed" customid="Hotspot 8"   datasizewidth="100.0px" datasizeheight="40.0px" dataX="124.0" dataY="455.4"  >\
        <div class="clickableSpot"></div>\
      </div>\
      </div>\
\
      </div>\
      <div id="loadMark"></div>\
    </div>\
  \
</div>\
';
document.getElementById("chromeTransfer").innerHTML = content;