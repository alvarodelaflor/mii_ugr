(function(window, undefined) {

  var jimLinks = {
    "19105cb3-7cb3-48f9-b9ab-ea11cd4dda8c" : {
      "Hotspot_1" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Hotspot_2" : [
        "ee726a37-d789-4e11-a5fb-ecf8f56efc08"
      ],
      "Hotspot_3" : [
        "28bd0908-8f53-432b-9c22-0861ab145ebf"
      ]
    },
    "856149c7-c793-4bca-abe5-16540ae06062" : {
      "Hotspot_1" : [
        "36018d71-3202-41de-b3c2-819a7a56e6ee"
      ],
      "Hotspot_2" : [
        "a9eb91c5-c292-4f8d-87cb-ad5363cb5291"
      ],
      "Hotspot_3" : [
        "4fc4d0c1-2401-442e-9920-77810637c702"
      ]
    },
    "12861226-040d-46b5-bbf4-d4e9f1a65925" : {
      "Hotspot_1" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Hotspot_2" : [
        "db194d42-9a14-4257-ab68-a849e80a2463"
      ],
      "Hotspot_3" : [
        "1840e065-8421-46bd-a9f3-a9a040339dac"
      ]
    },
    "a9eb91c5-c292-4f8d-87cb-ad5363cb5291" : {
      "Hotspot_1" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Hotspot_2" : [
        "eb265a93-a5e8-4ac0-a84e-985feda06e7d"
      ],
      "Hotspot_3" : [
        "36018d71-3202-41de-b3c2-819a7a56e6ee"
      ],
      "Hotspot_4" : [
        "38368b61-aac3-4148-b83e-87f2315caf72"
      ]
    },
    "ee726a37-d789-4e11-a5fb-ecf8f56efc08" : {
      "Hotspot_1" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Hotspot_2" : [
        "19105cb3-7cb3-48f9-b9ab-ea11cd4dda8c"
      ],
      "Hotspot_3" : [
        "28bd0908-8f53-432b-9c22-0861ab145ebf"
      ]
    },
    "4b3c2d77-6f14-4db8-8b0a-dac220765080" : {
      "Hotspot_1" : [
        "1840e065-8421-46bd-a9f3-a9a040339dac"
      ],
      "Hotspot_2" : [
        "5a4dfd63-daa7-4604-913e-890a968b60d1"
      ],
      "Hotspot_3" : [
        "eb265a93-a5e8-4ac0-a84e-985feda06e7d"
      ]
    },
    "864cb694-55a9-4991-8894-72207acfbc10" : {
      "Hotspot_1" : [
        "28bd0908-8f53-432b-9c22-0861ab145ebf"
      ],
      "Hotspot_2" : [
        "417e8f9f-87e3-4345-b81c-0245de3d3c79"
      ]
    },
    "417e8f9f-87e3-4345-b81c-0245de3d3c79" : {
      "Hotspot_1" : [
        "28bd0908-8f53-432b-9c22-0861ab145ebf"
      ],
      "Hotspot_2" : [
        "864cb694-55a9-4991-8894-72207acfbc10"
      ],
      "Hotspot_3" : [
        "daefcb8e-3ee7-4426-b5e9-cbb61f5199eb"
      ]
    },
    "4fc4d0c1-2401-442e-9920-77810637c702" : {
      "Image_1" : [
        "856149c7-c793-4bca-abe5-16540ae06062"
      ],
      "Hotspot_1" : [
        "36018d71-3202-41de-b3c2-819a7a56e6ee"
      ],
      "Hotspot_2" : [
        "856149c7-c793-4bca-abe5-16540ae06062"
      ],
      "Hotspot_3" : [
        "a9eb91c5-c292-4f8d-87cb-ad5363cb5291"
      ],
      "Hotspot_4" : [
        "28bd0908-8f53-432b-9c22-0861ab145ebf"
      ]
    },
    "5a4dfd63-daa7-4604-913e-890a968b60d1" : {
      "Hotspot_1" : [
        "1840e065-8421-46bd-a9f3-a9a040339dac"
      ],
      "Hotspot_2" : [
        "4b3c2d77-6f14-4db8-8b0a-dac220765080"
      ],
      "Hotspot_3" : [
        "eb265a93-a5e8-4ac0-a84e-985feda06e7d"
      ],
      "Hotspot_5" : [
        "28bd0908-8f53-432b-9c22-0861ab145ebf"
      ]
    },
    "28bd0908-8f53-432b-9c22-0861ab145ebf" : {
      "Hotspot_1" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Hotspot_2" : [
        "19105cb3-7cb3-48f9-b9ab-ea11cd4dda8c"
      ],
      "Hotspot_3" : [
        "ee726a37-d789-4e11-a5fb-ecf8f56efc08"
      ],
      "Hotspot_4" : [
        "864cb694-55a9-4991-8894-72207acfbc10"
      ]
    },
    "1840e065-8421-46bd-a9f3-a9a040339dac" : {
      "Hotspot_2" : [
        "4b3c2d77-6f14-4db8-8b0a-dac220765080"
      ],
      "Hotspot_3" : [
        "5a4dfd63-daa7-4604-913e-890a968b60d1"
      ],
      "Hotspot_4" : [
        "eb265a93-a5e8-4ac0-a84e-985feda06e7d"
      ],
      "Hotspot_5" : [
        "a9eb91c5-c292-4f8d-87cb-ad5363cb5291"
      ]
    },
    "38368b61-aac3-4148-b83e-87f2315caf72" : {
      "Hotspot_1" : [
        "a9eb91c5-c292-4f8d-87cb-ad5363cb5291"
      ]
    },
    "36018d71-3202-41de-b3c2-819a7a56e6ee" : {
      "Hotspot_1" : [
        "a9eb91c5-c292-4f8d-87cb-ad5363cb5291"
      ],
      "Hotspot_2" : [
        "856149c7-c793-4bca-abe5-16540ae06062"
      ],
      "Hotspot_3" : [
        "4fc4d0c1-2401-442e-9920-77810637c702"
      ],
      "Hotspot_5" : [
        "a9eb91c5-c292-4f8d-87cb-ad5363cb5291"
      ]
    },
    "eb265a93-a5e8-4ac0-a84e-985feda06e7d" : {
      "Hotspot_1" : [
        "a9eb91c5-c292-4f8d-87cb-ad5363cb5291"
      ],
      "Hotspot_2" : [
        "a9eb91c5-c292-4f8d-87cb-ad5363cb5291"
      ],
      "Hotspot_3" : [
        "12861226-040d-46b5-bbf4-d4e9f1a65925"
      ]
    },
    "5d555f56-c816-40e5-abc9-b44b033dde3f" : {
      "Hotspot_1" : [
        "23a795b7-3f17-472c-bbdf-0ab8ff624e40"
      ]
    },
    "930fb022-d940-4e98-b537-69b85ec4ca3c" : {
      "Hotspot_1" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Hotspot_3" : [
        "5d555f56-c816-40e5-abc9-b44b033dde3f"
      ],
      "Hotspot_4" : [
        "23a795b7-3f17-472c-bbdf-0ab8ff624e40"
      ],
      "Hotspot_5" : [
        "23a795b7-3f17-472c-bbdf-0ab8ff624e40"
      ],
      "Hotspot_6" : [
        "23a795b7-3f17-472c-bbdf-0ab8ff624e40"
      ],
      "Hotspot_7" : [
        "23a795b7-3f17-472c-bbdf-0ab8ff624e40"
      ],
      "Hotspot_8" : [
        "23a795b7-3f17-472c-bbdf-0ab8ff624e40"
      ],
      "Hotspot_9" : [
        "23a795b7-3f17-472c-bbdf-0ab8ff624e40"
      ],
      "Hotspot_10" : [
        "23a795b7-3f17-472c-bbdf-0ab8ff624e40"
      ],
      "Hotspot_11" : [
        "23a795b7-3f17-472c-bbdf-0ab8ff624e40"
      ],
      "Hotspot_17" : [
        "930fb022-d940-4e98-b537-69b85ec4ca3c"
      ],
      "Hotspot_18" : [
        "930fb022-d940-4e98-b537-69b85ec4ca3c"
      ],
      "Hotspot_19" : [
        "930fb022-d940-4e98-b537-69b85ec4ca3c"
      ],
      "Hotspot_20" : [
        "930fb022-d940-4e98-b537-69b85ec4ca3c"
      ],
      "Hotspot_21" : [
        "d12245cc-1680-458d-89dd-4f0d7fb22724"
      ],
      "Hotspot_22" : [
        "930fb022-d940-4e98-b537-69b85ec4ca3c"
      ]
    },
    "23a795b7-3f17-472c-bbdf-0ab8ff624e40" : {
      "Hotspot_1" : [
        "930fb022-d940-4e98-b537-69b85ec4ca3c"
      ]
    },
    "daefcb8e-3ee7-4426-b5e9-cbb61f5199eb" : {
      "Hotspot_1" : [
        "28bd0908-8f53-432b-9c22-0861ab145ebf"
      ],
      "Hotspot_2" : [
        "417e8f9f-87e3-4345-b81c-0245de3d3c79"
      ],
      "Hotspot_3" : [
        "28bd0908-8f53-432b-9c22-0861ab145ebf"
      ]
    },
    "db194d42-9a14-4257-ab68-a849e80a2463" : {
      "Image_1" : [
        "49218415-2f65-4590-aff1-692b6743d7a0"
      ],
      "Hotspot_2" : [
        "12861226-040d-46b5-bbf4-d4e9f1a65925"
      ],
      "Hotspot_3" : [
        "db194d42-9a14-4257-ab68-a849e80a2463"
      ],
      "Hotspot_6" : [
        "db194d42-9a14-4257-ab68-a849e80a2463"
      ],
      "Hotspot_7" : [
        "db194d42-9a14-4257-ab68-a849e80a2463"
      ],
      "Hotspot_8" : [
        "12861226-040d-46b5-bbf4-d4e9f1a65925"
      ]
    },
    "d12245cc-1680-458d-89dd-4f0d7fb22724" : {
      "Hotspot_1" : [
        "a9eb91c5-c292-4f8d-87cb-ad5363cb5291"
      ],
      "Hotspot_2" : [
        "db194d42-9a14-4257-ab68-a849e80a2463"
      ],
      "Hotspot_3" : [
        "930fb022-d940-4e98-b537-69b85ec4ca3c"
      ],
      "Hotspot_4" : [
        "19105cb3-7cb3-48f9-b9ab-ea11cd4dda8c"
      ]
    }    
  }

  window.jimLinks = jimLinks;
})(window);