(function(window, undefined) {
  var dictionary = {
    "19105cb3-7cb3-48f9-b9ab-ea11cd4dda8c": "Información_receta",
    "856149c7-c793-4bca-abe5-16540ae06062": "Ingredientes_receta_modificar_menú",
    "12861226-040d-46b5-bbf4-d4e9f1a65925": "Buscar_recetas_organizar_menú",
    "a9eb91c5-c292-4f8d-87cb-ad5363cb5291": "Calendario",
    "ee726a37-d789-4e11-a5fb-ecf8f56efc08": "Ingredientes_receta",
    "4b3c2d77-6f14-4db8-8b0a-dac220765080": "Ingredientes_receta_hacer_menú",
    "864cb694-55a9-4991-8894-72207acfbc10": "Paso_1_receta",
    "417e8f9f-87e3-4345-b81c-0245de3d3c79": "Paso_2_receta",
    "05612221-a976-4796-a08b-63e1c3ce870f": "Menú_exp_dificultad",
    "4fc4d0c1-2401-442e-9920-77810637c702": "Pasos_receta_modificar_menú",
    "5a4dfd63-daa7-4604-913e-890a968b60d1": "Pasos_receta_hacer_menú",
    "28bd0908-8f53-432b-9c22-0861ab145ebf": "Pasos_receta",
    "49218415-2f65-4590-aff1-692b6743d7a0": "Menú_exp_comida",
    "1840e065-8421-46bd-a9f3-a9a040339dac": "Información_receta_hacer_menú",
    "38368b61-aac3-4148-b83e-87f2315caf72": "Se_come_fuera",
    "747a7255-7d8f-4933-be32-6e712798501e": "Menú_exp_dieta",
    "36018d71-3202-41de-b3c2-819a7a56e6ee": "Información_receta_modificar_menú",
    "eb265a93-a5e8-4ac0-a84e-985feda06e7d": "Seleccionar_día_menú",
    "5d555f56-c816-40e5-abc9-b44b033dde3f": "Tomar_foto",
    "930fb022-d940-4e98-b537-69b85ec4ca3c": "Publicar_receta",
    "23a795b7-3f17-472c-bbdf-0ab8ff624e40": "Añadir_foto",
    "daefcb8e-3ee7-4426-b5e9-cbb61f5199eb": "Paso_fin_receta",
    "db194d42-9a14-4257-ab68-a849e80a2463": "Filtro_receta",
    "d12245cc-1680-458d-89dd-4f0d7fb22724": "Recetas",
    "f39803f7-df02-4169-93eb-7547fb8c961a": "Template 1",
    "bb8abf58-f55e-472d-af05-a7d1bb0cc014": "default"
  };

  var uriRE = /^(\/#)?(screens|templates|masters|scenarios)\/(.*)(\.html)?/;
  window.lookUpURL = function(fragment) {
    var matches = uriRE.exec(fragment || "") || [],
        folder = matches[2] || "",
        canvas = matches[3] || "",
        name, url;
    if(dictionary.hasOwnProperty(canvas)) { /* search by name */
      url = folder + "/" + canvas;
    }
    return url;
  };

  window.lookUpName = function(fragment) {
    var matches = uriRE.exec(fragment || "") || [],
        folder = matches[2] || "",
        canvas = matches[3] || "",
        name, canvasName;
    if(dictionary.hasOwnProperty(canvas)) { /* search by name */
      canvasName = dictionary[canvas];
    }
    return canvasName;
  };
})(window);