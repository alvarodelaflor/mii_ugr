package practica1;

public enum Status {
	ON, OFF
}
