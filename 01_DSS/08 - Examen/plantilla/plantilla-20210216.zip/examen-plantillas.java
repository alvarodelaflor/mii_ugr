import java.io.Serializable;
import java.util.ArrayList;

public class Tarjeta implements Serializable {

    private ArrayList<LineaArticulo> articulos;

    public Cart() {
        articulos = new ArrayList<LineaArticulo>();
    }

    public ArrayList<LineaArticulo> getarticulos() {
        return articulos;
    }

    public int getCount() {
        return articulos.size();
    }

    public void addItem(LineaArticulo item) {
        String codigo = item.getproducto().getcodigo();
        int cantidad = item.getcantidad();
        for (int i = 0; i < articulos.size(); i++) {
            LineaArticulo LineaArticulo = articulos.get(i);
            if (LineaArticulo.getproducto().getcodigo().equals(codigo)) {
                LineaArticulo.setcantidad(cantidad);
                return;
            }
        }
        articulos.add(item);
    }

    public void removeItem(LineaArticulo item) {
        String codigo = item.getproducto().getcodigo();
        for (int i = 0; i < articulos.size(); i++) {
            LineaArticulo LineaArticulo = articulos.get(i);
            if (LineaArticulo.getproducto().getcodigo().equals(codigo)) {
                articulos.remove(i);
                return;
            }
        }
    }
}
//--------------------------------------------------------------------
import java.io.Serializable;
import java.text.NumberFormat;

public class LineaArticulo implements Serializable {

    private producto producto;
    private int cantidad;

    public LineaArticulo() {}

    public void setproducto(producto p) {
        producto = p;
    }

    public producto getproducto() {
        return producto;
    }

    public void setcantidad(int cantidad) {
        this.cantidad = cantidad;
    }

    public int getcantidad() {
        return cantidad;
    }

    public double getTotal() {
        double total = producto.getprecio() * cantidad;
        return total;
    }

    public String getTotalmonedaFormat() {
        NumberFormat moneda = NumberFormat.getmonedaInstancia();
        return moneda.format(this.getTotal());
    }
}
//-------------------------------------------------------
public class Producto implements Serializable {

    private String codigo;
    private String descripcion;
    private double precio;

    public Producto() {
        codigo = "";
        descripcion = "";
        precio = 0;
    }

    public void setcodigo(String codigo) {
        this.codigo = codigo;
    }

    public String getcodigo() {
        return codigo;
    }

    public void setdescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public String getdescripcion() {
        return descripcion;
    }

    public void setprecio(double precio) {
        this.precio = precio;
    }

    public double getprecio() {
        return precio;
    }

    public String getpreciomonedaFormat() {
        NumberFormat moneda = NumberFormat.getmonedaInstancia();
        return moneda.format(precio);
    }
}

